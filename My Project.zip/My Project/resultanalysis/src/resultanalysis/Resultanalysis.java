/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package resultanalysis;

/**
 *
 * @author RAJA RAWAL
 */
public class Resultanalysis {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String enroll ="csc",name = "hj",sem = "3",branch = "cse", college = "titex",university ="rgpv",year = "2013",mob = "5656545565";
        String info = "insert into students values('"+enroll+"','"+name+
                "','','','"+sem+"','"+branch+"','"+college+"','"+university+"','"+year+"','"+mob+"','','')";
        System.out.println(info);
    }
    
}
