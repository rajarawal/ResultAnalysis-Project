
package resultanalysis;

import java.awt.HeadlessException;
import java.sql.SQLException;
import javax.swing.JDialog;
import javax.swing.JOptionPane;


public class ResultsEntry extends javax.swing.JDialog {

    
    JDialog d;
    Databaseconnection db,db2;
    int totaltmark1,totaltmark2,totaltmark3,totaltmark4,totaltmark5;
    int totalpmark1,totalpmark2,totalpmark3,totalpmark4,totalpmark5,totalpmark6;
    String enrollment,semester=" ";
    String set1,set2,set3,set4,set5,smt1,smt2,smt3,smt4;
    String smt5,sat1,sat2,sat3,sat4,sat5;
    String sep1,sep2,sep3,sep4,sep5,sep6,smp1,smp2,smp3,smp4,smp5,smp6;
    String sap1,sap2,sap3,sap4,sap5,sap6;
    String grt1,grt2,grt3,grt4,grt5,grp1,grp2,grp3,grp4,grp5,grp6;
    int tt1=0,tt2=0,tt3=0,tt4=0,tt5=0,tp1=0,tp2=0,tp3=0,tp4=0,tp5=0,tp6=0;
    float sgpa;
   // String f_status = "";
    public ResultsEntry(javax.swing.JDialog parent, boolean modal) {
        super(parent, modal);
        db = new Databaseconnection();
        db2 = new Databaseconnection();
        initComponents();
      //   ob = new ResultsEntry(this,true);
        d = parent;
        this.setVisible(true);
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel35 = new javax.swing.JLabel();
        enroll = new javax.swing.JTextField();
        jLabel36 = new javax.swing.JLabel();
        semesterTF = new javax.swing.JTextField();
        jPanel3 = new javax.swing.JPanel();
        jLabel84 = new javax.swing.JLabel();
        jLabel83 = new javax.swing.JLabel();
        jLabel82 = new javax.swing.JLabel();
        jLabel81 = new javax.swing.JLabel();
        jLabel80 = new javax.swing.JLabel();
        jLabel79 = new javax.swing.JLabel();
        jLabel78 = new javax.swing.JLabel();
        jLabel44 = new javax.swing.JLabel();
        l1 = new javax.swing.JLabel();
        l2 = new javax.swing.JLabel();
        l3 = new javax.swing.JLabel();
        l4 = new javax.swing.JLabel();
        l5 = new javax.swing.JLabel();
        jLabel49 = new javax.swing.JLabel();
        jLabel50 = new javax.swing.JLabel();
        ettf1 = new javax.swing.JTextField();
        ettf2 = new javax.swing.JTextField();
        ettf3 = new javax.swing.JTextField();
        ettf4 = new javax.swing.JTextField();
        ettf5 = new javax.swing.JTextField();
        jLabel51 = new javax.swing.JLabel();
        jLabel52 = new javax.swing.JLabel();
        mttf1 = new javax.swing.JTextField();
        mttf2 = new javax.swing.JTextField();
        mttf3 = new javax.swing.JTextField();
        mttf4 = new javax.swing.JTextField();
        mttf5 = new javax.swing.JTextField();
        jLabel53 = new javax.swing.JLabel();
        jLabel54 = new javax.swing.JLabel();
        attf1 = new javax.swing.JTextField();
        attf2 = new javax.swing.JTextField();
        attf3 = new javax.swing.JTextField();
        attf4 = new javax.swing.JTextField();
        attf5 = new javax.swing.JTextField();
        jLabel55 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        t1 = new javax.swing.JTextField();
        t2 = new javax.swing.JTextField();
        t3 = new javax.swing.JTextField();
        t4 = new javax.swing.JTextField();
        t5 = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        gt1 = new javax.swing.JLabel();
        gt2 = new javax.swing.JLabel();
        gt3 = new javax.swing.JLabel();
        gt4 = new javax.swing.JLabel();
        gt5 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel56 = new javax.swing.JLabel();
        jLabel57 = new javax.swing.JLabel();
        jLabel58 = new javax.swing.JLabel();
        jLabel59 = new javax.swing.JLabel();
        jLabel60 = new javax.swing.JLabel();
        jLabel61 = new javax.swing.JLabel();
        jLabel62 = new javax.swing.JLabel();
        jLabel63 = new javax.swing.JLabel();
        l6 = new javax.swing.JLabel();
        l7 = new javax.swing.JLabel();
        l8 = new javax.swing.JLabel();
        l9 = new javax.swing.JLabel();
        l10 = new javax.swing.JLabel();
        l11 = new javax.swing.JLabel();
        jLabel69 = new javax.swing.JLabel();
        eptf1 = new javax.swing.JTextField();
        eptf2 = new javax.swing.JTextField();
        eptf3 = new javax.swing.JTextField();
        eptf4 = new javax.swing.JTextField();
        eptf5 = new javax.swing.JTextField();
        eptf6 = new javax.swing.JTextField();
        jLabel71 = new javax.swing.JLabel();
        lptf1 = new javax.swing.JTextField();
        lptf2 = new javax.swing.JTextField();
        lptf3 = new javax.swing.JTextField();
        lptf4 = new javax.swing.JTextField();
        lptf5 = new javax.swing.JTextField();
        lptf6 = new javax.swing.JTextField();
        jLabel72 = new javax.swing.JLabel();
        aptf1 = new javax.swing.JTextField();
        aptf2 = new javax.swing.JTextField();
        aptf3 = new javax.swing.JTextField();
        aptf4 = new javax.swing.JTextField();
        aptf5 = new javax.swing.JTextField();
        aptf6 = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        tfp1 = new javax.swing.JTextField();
        tfp2 = new javax.swing.JTextField();
        tfp3 = new javax.swing.JTextField();
        tfp4 = new javax.swing.JTextField();
        tfp5 = new javax.swing.JTextField();
        tfp6 = new javax.swing.JTextField();
        Grade = new javax.swing.JLabel();
        gp1 = new javax.swing.JLabel();
        gp2 = new javax.swing.JLabel();
        gp3 = new javax.swing.JLabel();
        gp4 = new javax.swing.JLabel();
        gp5 = new javax.swing.JLabel();
        gp6 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Result Entry Form");
        setPreferredSize(new java.awt.Dimension(1203, 755));

        jLabel35.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel35.setText("Enrollment");

        enroll.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        enroll.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                enrollFocusLost(evt);
            }
        });
        enroll.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                enrollKeyReleased(evt);
            }
        });

        jLabel36.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel36.setText("Semester");

        semesterTF.setEditable(false);
        semesterTF.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(83, Short.MAX_VALUE)
                .addComponent(jLabel35, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(78, 78, 78)
                .addComponent(enroll, javax.swing.GroupLayout.PREFERRED_SIZE, 177, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(44, 44, 44)
                .addComponent(jLabel36, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(60, 60, 60)
                .addComponent(semesterTF, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(501, 501, 501))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel35, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(enroll, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel36, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(semesterTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(24, Short.MAX_VALUE))
        );

        jPanel3.setLayout(new java.awt.GridLayout(17, 7));

        jLabel84.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel84.setText("TheoryMarks");
        jPanel3.add(jLabel84);
        jPanel3.add(jLabel83);
        jPanel3.add(jLabel82);
        jPanel3.add(jLabel81);
        jPanel3.add(jLabel80);
        jPanel3.add(jLabel79);
        jPanel3.add(jLabel78);
        jPanel3.add(jLabel44);

        l1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        l1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jPanel3.add(l1);

        l2.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        l2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jPanel3.add(l2);

        l3.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        l3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jPanel3.add(l3);

        l4.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        l4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jPanel3.add(l4);

        l5.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        l5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jPanel3.add(l5);
        jPanel3.add(jLabel49);

        jLabel50.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel50.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel50.setText("EndSem");
        jPanel3.add(jLabel50);

        ettf1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        ettf1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        ettf1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                ettf1KeyReleased(evt);
            }
        });
        jPanel3.add(ettf1);

        ettf2.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        ettf2.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        ettf2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ettf2ActionPerformed(evt);
            }
        });
        ettf2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                ettf2KeyReleased(evt);
            }
        });
        jPanel3.add(ettf2);

        ettf3.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        ettf3.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        ettf3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ettf3ActionPerformed(evt);
            }
        });
        ettf3.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                ettf3KeyReleased(evt);
            }
        });
        jPanel3.add(ettf3);

        ettf4.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        ettf4.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        ettf4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ettf4ActionPerformed(evt);
            }
        });
        ettf4.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                ettf4KeyReleased(evt);
            }
        });
        jPanel3.add(ettf4);

        ettf5.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        ettf5.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        ettf5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ettf5ActionPerformed(evt);
            }
        });
        ettf5.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                ettf5KeyReleased(evt);
            }
        });
        jPanel3.add(ettf5);
        jPanel3.add(jLabel51);

        jLabel52.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel52.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel52.setText("Mid Sem");
        jPanel3.add(jLabel52);

        mttf1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        mttf1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        mttf1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                mttf1KeyReleased(evt);
            }
        });
        jPanel3.add(mttf1);

        mttf2.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        mttf2.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        mttf2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mttf2ActionPerformed(evt);
            }
        });
        mttf2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                mttf2KeyReleased(evt);
            }
        });
        jPanel3.add(mttf2);

        mttf3.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        mttf3.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        mttf3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mttf3ActionPerformed(evt);
            }
        });
        mttf3.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                mttf3KeyReleased(evt);
            }
        });
        jPanel3.add(mttf3);

        mttf4.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        mttf4.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        mttf4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mttf4ActionPerformed(evt);
            }
        });
        mttf4.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                mttf4KeyReleased(evt);
            }
        });
        jPanel3.add(mttf4);

        mttf5.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        mttf5.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        mttf5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mttf5ActionPerformed(evt);
            }
        });
        mttf5.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                mttf5KeyReleased(evt);
            }
        });
        jPanel3.add(mttf5);
        jPanel3.add(jLabel53);

        jLabel54.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel54.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel54.setText("Assignment");
        jPanel3.add(jLabel54);

        attf1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        attf1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        attf1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                attf1KeyReleased(evt);
            }
        });
        jPanel3.add(attf1);

        attf2.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        attf2.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        attf2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                attf2ActionPerformed(evt);
            }
        });
        attf2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                attf2KeyReleased(evt);
            }
        });
        jPanel3.add(attf2);

        attf3.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        attf3.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        attf3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                attf3ActionPerformed(evt);
            }
        });
        attf3.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                attf3KeyReleased(evt);
            }
        });
        jPanel3.add(attf3);

        attf4.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        attf4.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        attf4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                attf4ActionPerformed(evt);
            }
        });
        attf4.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                attf4KeyReleased(evt);
            }
        });
        jPanel3.add(attf4);

        attf5.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        attf5.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        attf5.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                attf5KeyReleased(evt);
            }
        });
        jPanel3.add(attf5);
        jPanel3.add(jLabel55);

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel9.setText("Total Marks");
        jPanel3.add(jLabel9);

        t1.setEditable(false);
        t1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        t1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jPanel3.add(t1);

        t2.setEditable(false);
        t2.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        t2.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jPanel3.add(t2);

        t3.setEditable(false);
        t3.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        t3.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jPanel3.add(t3);

        t4.setEditable(false);
        t4.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        t4.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jPanel3.add(t4);

        t5.setEditable(false);
        t5.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        t5.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jPanel3.add(t5);
        jPanel3.add(jLabel6);

        jLabel15.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel15.setText("Grade");
        jPanel3.add(jLabel15);

        gt1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        gt1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jPanel3.add(gt1);

        gt2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        gt2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jPanel3.add(gt2);

        gt3.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        gt3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jPanel3.add(gt3);

        gt4.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        gt4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jPanel3.add(gt4);

        gt5.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        gt5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jPanel3.add(gt5);
        jPanel3.add(jLabel12);
        jPanel3.add(jLabel11);
        jPanel3.add(jLabel13);
        jPanel3.add(jLabel14);
        jPanel3.add(jLabel17);
        jPanel3.add(jLabel19);
        jPanel3.add(jLabel10);
        jPanel3.add(jLabel8);

        jLabel56.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel56.setText("PracticalMarks");
        jPanel3.add(jLabel56);
        jPanel3.add(jLabel57);
        jPanel3.add(jLabel58);
        jPanel3.add(jLabel59);
        jPanel3.add(jLabel60);
        jPanel3.add(jLabel61);
        jPanel3.add(jLabel62);
        jPanel3.add(jLabel63);

        l6.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        l6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jPanel3.add(l6);

        l7.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        l7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jPanel3.add(l7);

        l8.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        l8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jPanel3.add(l8);

        l9.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        l9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jPanel3.add(l9);

        l10.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        l10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jPanel3.add(l10);

        l11.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        l11.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jPanel3.add(l11);

        jLabel69.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel69.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel69.setText("End-Sem");
        jPanel3.add(jLabel69);

        eptf1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        eptf1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        eptf1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                eptf1KeyReleased(evt);
            }
        });
        jPanel3.add(eptf1);

        eptf2.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        eptf2.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        eptf2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                eptf2KeyReleased(evt);
            }
        });
        jPanel3.add(eptf2);

        eptf3.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        eptf3.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        eptf3.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                eptf3KeyReleased(evt);
            }
        });
        jPanel3.add(eptf3);

        eptf4.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        eptf4.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        eptf4.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                eptf4KeyReleased(evt);
            }
        });
        jPanel3.add(eptf4);

        eptf5.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        eptf5.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        eptf5.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                eptf5KeyReleased(evt);
            }
        });
        jPanel3.add(eptf5);

        eptf6.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        eptf6.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        eptf6.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                eptf6KeyReleased(evt);
            }
        });
        jPanel3.add(eptf6);

        jLabel71.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel71.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel71.setText("LabWork");
        jPanel3.add(jLabel71);

        lptf1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lptf1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        lptf1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                lptf1KeyReleased(evt);
            }
        });
        jPanel3.add(lptf1);

        lptf2.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lptf2.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        lptf2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                lptf2KeyReleased(evt);
            }
        });
        jPanel3.add(lptf2);

        lptf3.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lptf3.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        lptf3.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                lptf3KeyReleased(evt);
            }
        });
        jPanel3.add(lptf3);

        lptf4.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lptf4.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        lptf4.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                lptf4KeyReleased(evt);
            }
        });
        jPanel3.add(lptf4);

        lptf5.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lptf5.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        lptf5.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                lptf5KeyReleased(evt);
            }
        });
        jPanel3.add(lptf5);

        lptf6.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lptf6.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        lptf6.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                lptf6KeyReleased(evt);
            }
        });
        jPanel3.add(lptf6);

        jLabel72.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel72.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel72.setText("Assignment");
        jPanel3.add(jLabel72);

        aptf1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        aptf1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        aptf1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                aptf1KeyReleased(evt);
            }
        });
        jPanel3.add(aptf1);

        aptf2.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        aptf2.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        aptf2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                aptf2KeyReleased(evt);
            }
        });
        jPanel3.add(aptf2);

        aptf3.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        aptf3.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        aptf3.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                aptf3KeyReleased(evt);
            }
        });
        jPanel3.add(aptf3);

        aptf4.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        aptf4.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        aptf4.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                aptf4KeyReleased(evt);
            }
        });
        jPanel3.add(aptf4);

        aptf5.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        aptf5.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        aptf5.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                aptf5KeyReleased(evt);
            }
        });
        jPanel3.add(aptf5);

        aptf6.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        aptf6.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        aptf6.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                aptf6KeyReleased(evt);
            }
        });
        jPanel3.add(aptf6);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel1.setText("Total Marks");
        jPanel3.add(jLabel1);

        tfp1.setEditable(false);
        tfp1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        tfp1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jPanel3.add(tfp1);

        tfp2.setEditable(false);
        tfp2.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        tfp2.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jPanel3.add(tfp2);

        tfp3.setEditable(false);
        tfp3.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        tfp3.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jPanel3.add(tfp3);

        tfp4.setEditable(false);
        tfp4.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        tfp4.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jPanel3.add(tfp4);

        tfp5.setEditable(false);
        tfp5.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        tfp5.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jPanel3.add(tfp5);

        tfp6.setEditable(false);
        tfp6.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        tfp6.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jPanel3.add(tfp6);

        Grade.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        Grade.setText("Grade");
        jPanel3.add(Grade);

        gp1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        gp1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jPanel3.add(gp1);

        gp2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        gp2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jPanel3.add(gp2);

        gp3.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        gp3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jPanel3.add(gp3);

        gp4.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        gp4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jPanel3.add(gp4);

        gp5.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        gp5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jPanel3.add(gp5);

        gp6.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        gp6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jPanel3.add(gp6);
        jPanel3.add(jLabel25);
        jPanel3.add(jLabel24);
        jPanel3.add(jLabel23);
        jPanel3.add(jLabel22);
        jPanel3.add(jLabel21);
        jPanel3.add(jLabel20);
        jPanel3.add(jLabel16);
        jPanel3.add(jLabel5);
        jPanel3.add(jLabel4);
        jPanel3.add(jLabel3);
        jPanel3.add(jLabel2);
        jPanel3.add(jLabel18);

        jButton4.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jButton4.setText("Cancel");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton4);

        jButton5.setFont(new java.awt.Font("Tahoma", 3, 24)); // NOI18N
        jButton5.setText("Submit");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton5);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 600, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(65, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
public void subjectShow()
{
        String sem;
        enrollment = enroll.getText();
        //System.out.println("Semester is "+enrollment);
        
        try{
            sem = "SELECT * FROM students WHERE Enrollment='"+enrollment+"'";
            db.rs = db.stmt.executeQuery(sem);
            while(db.rs.next())
                
            {
                semester = db.rs.getString(6);
                //System.out.println(semester);
            }
            if(Integer.parseInt(semester) < 3){
            eptf6.setVisible(false);
            lptf6.setVisible(false);
            aptf6.setVisible(false);
            tfp6.setVisible(false);
        }
        }catch(Exception e)
        {}
        
        semesterTF.setText("Sem-"+semester);
        String sub, s1;
        try{
            
        sub = "SELECT * FROM subjects where sub_code  like '_____[T]' and semester='"+semester+"'";
        db.rs = db.stmt.executeQuery(sub);
        int t = 0;
        while(db.rs.next())
        {
            t = t + 1;
            if(t == 1){
                l1.setText(db.rs.getString(2));
            }
            if(t == 2){
                l2.setText(db.rs.getString(2));
            }
             if(t == 3){
                l3.setText(db.rs.getString(2));
            }
              if(t == 4){
                l4.setText(db.rs.getString(2));
            }
               if(t == 5){
                l5.setText(db.rs.getString(2));
            }
            
        }
        
        
        
        }catch(Exception e)
        {}
        String pract ;
        try{
        pract = "SELECT * FROM subjects where sub_code  like '_____[P]' and semester='"+semester+"'";
        db.rs = db.stmt.executeQuery(pract);
        int t1 = 0;
        while(db.rs.next()){
            t1 = t1 + 1;
            if(t1 == 1)
                l6.setText(db.rs.getString(2));
            if(t1 == 2)
                l7.setText(db.rs.getString(2));
            if(t1 == 3)
                l8.setText(db.rs.getString(2));
            if(t1 == 4)
                l9.setText(db.rs.getString(2));
            if(t1 == 5)
                l10.setText(db.rs.getString(2));
            if(t1 == 6)
                l11.setText(db.rs.getString(2));
        }
        }catch(Exception e){
            
        }
        
        

}
    private void ettf3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ettf3ActionPerformed
       
    }//GEN-LAST:event_ettf3ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        /*String et1,et2,et3,et4,et5,mt1,mt2,mt3,mt4,mt5,at1,at2,at3,at4,at5;
        String ep1,ep2,ep3,ep4,ep5,ep6=null,lp1,lp2,lp3,lp4,lp5,lp6=null,ap1,ap2,ap3,ap4,ap5,ap6=null;
        String e1= enroll.getText();
        et1 = ettf1.getText();
        et2 = ettf2.getText();
        et3= ettf3.getText();
        et4 = ettf4.getText();
        et5 = ettf5.getText();
        mt1 = mttf1.getText();
        mt2 = mttf2.getText();
        mt3 = mttf3.getText();
        mt4 = mttf4.getText();
        mt5 = mttf5.getText();
        at1 = attf1.getText();
        at2 = attf2.getText();
        at3 = attf3.getText();
        at4 = attf4.getText();
        at5 = attf5.getText();
        ep1 = eptf1.getText();
        ep2 = eptf2.getText();
        ep3 = eptf3.getText();
        ep4 = eptf4.getText();
        ep5 = eptf5.getText();
        lp1 = lptf1.getText();
        lp2 = lptf2.getText();
        lp3 = lptf3.getText();
        lp4 = lptf4.getText();
        lp5 = lptf5.getText();
        ap1 = aptf1.getText();
        ap2 = aptf2.getText();
        ap3 = aptf3.getText();
        ap4 = aptf4.getText();
        ap5 = aptf5.getText();
        String sm= semesterTF.getText();
        if(Integer.parseInt(sm) > 2){
            ep6 = eptf6.getText();
            lp6 = lptf6.getText();
            ap6 = aptf6.getText();
        }
        int t = 0;
        if(e1 == null || et1 == null || et2 == null || et3 == null || et4 == null || et5 == null || mt1 == null ||
                mt2 == null || mt3 == null || mt4 == null || mt5 == null || at1 == null || at2 == null || at3 == null ||
                at4 == null || at5 == null || ep1 == null || ep2 == null || ep3 == null || ep4 == null || ep5 == null ||
                lp1 == null || lp2 == null || lp3 == null || lp4 == null || lp5 == null ||
                ap1 == null || ap2 == null || ap3 == null || ap4 == null || ap5 == null ){
            t=1;
        }
            if(Integer.parseInt(sm) > 2)
            {

        if(e1 == null || et1 == null || et2 == null || et3 == null || et4 == null || et5 == null || mt1 == null ||
                mt2 == null || mt3 == null || mt4 == null || mt5 == null || at1 == null || at2 == null || at3 == null ||
                at4 == null || at5 == null || ep1 == null || ep2 == null || ep3 == null || ep4 == null || ep5 == null ||
                lp1 == null || lp2 == null || lp3 == null || lp4 == null || lp5 == null ||
                ap1 == null || ap2 == null || ap3 == null || ap4 == null || ap5 == null || ap6 == null || lp6 ==null || ep6 ==null )
        
            t=1;
        }
            if( t== 1)
                JOptionPane.showMessageDialog(null,"Plz Fill All Marks..\n Thank You");
            else{*/
            
        SGPA();
        CGPA();
        String s1 = l1.getText();
        String s2 = l2.getText();
        String s3 = l3.getText();
        String s4 = l4.getText();
        String s5 = l5.getText();
        String statust = "",totalmarkt;
        try{
        String insert = "Insert into theorymarks values('"+enrollment+"','"+semester+"','"+s1+"','"+set1+"','"+smt1+"','"+sat1+"')";
        db.stmt.executeUpdate(insert);
        if(totaltmark1 > 40 && Integer.parseInt(set1) > 23){
            statust = "Pass";
            //f_status ="Pass";
        }
        else{
            
            statust = "Fail";
           // f_status ="Fail in \n";
            //f_status = f_status+s1;
        }
        totalmarkt = "Insert into results values('"+enrollment+"','"+semester+"','"+s1+"','"+totaltmark1+"','"+grt1+"','"+statust+"')";
        db.stmt.executeUpdate(totalmarkt);
        insert = "Insert into theorymarks values('"+enrollment+"','"+semester+"','"+s2+"','"+set2+"','"+smt2+"','"+sat2+"')";
        db.stmt.executeUpdate(insert);
        if(totaltmark2 > 40 && Integer.parseInt(set2) > 23)
            statust = "Pass";
        else
            statust = "Fail";
        totalmarkt = "Insert into results values('"+enrollment+"','"+semester+"','"+s2+"','"+totaltmark2+"','"+grt2+"','"+statust+"')";
        db.stmt.executeUpdate(totalmarkt);
        insert = "Insert into theorymarks values('"+enrollment+"','"+semester+"','"+s3+"','"+set3+"','"+smt3+"','"+sat3+"')";
        db.stmt.executeUpdate(insert);
        if(totaltmark3 > 40 && Integer.parseInt(set3) > 23)
            statust = "Pass";
        else
            statust = "Fail";
        totalmarkt = "Insert into results values('"+enrollment+"','"+semester+"','"+s3+"','"+totaltmark3+"','"+grt3+"','"+statust+"')";
        db.stmt.executeUpdate(totalmarkt);
        insert = "Insert into theorymarks values('"+enrollment+"','"+semester+"','"+s4+"','"+set4+"','"+smt4+"','"+sat4+"')";
        db.stmt.executeUpdate(insert);
        if(totaltmark4 > 40 && Integer.parseInt(set4) > 23)
            statust = "Pass";
        else
            statust = "Fail";
        totalmarkt = "Insert into results values('"+enrollment+"','"+semester+"','"+s4+"','"+totaltmark4+"','"+grt4+"','"+statust+"')";
        db.stmt.executeUpdate(totalmarkt);
        insert = "Insert into theorymarks values('"+enrollment+"','"+semester+"','"+s5+"','"+set5+"','"+smt5+"','"+sat5+"')";
        db.stmt.executeUpdate(insert);
        if(totaltmark5 > 40 && Integer.parseInt(set5) > 23)
            statust = "Pass";
        else
            statust = "Fail";
        totalmarkt = "Insert into results values('"+enrollment+"','"+semester+"','"+s5+"','"+totaltmark5+"','"+grt5+"','"+statust+"')";
        db.stmt.executeUpdate(totalmarkt);
        }catch(SQLException | NumberFormatException e){}       
        String sp1 = l6.getText();
        String sp2 = l7.getText();
        String sp3 = l8.getText();
        String sp4 = l9.getText();
        String sp5 = l10.getText();
        String sp6 = l11.getText();
        String status = "";
        try{
        String insertp = "Insert into practicalmarks values('"+enrollment+"','"+semester+"','"+sp1+"','"+sep1+"','"+smp1+"','"+sap1+"')";
        db.stmt.executeUpdate(insertp);
        if(totalpmark1 > 20)
            status = "Pass";
        else
            status = "Fail";
        String totalmark = "Insert into results values('"+enrollment+"','"+semester+"','"+sp1+"','"+totalpmark1+"','"+grp1+"','"+status+"')";
        db.stmt.executeUpdate(totalmark);
        insertp = "Insert into practicalmarks values('"+enrollment+"','"+semester+"','"+sp2+"','"+sep2+"','"+smp2+"','"+sap1+"')";
        db.stmt.executeUpdate(insertp);
        if(totalpmark2 > 20)
            status = "Pass";
        else
            status = "Fail";
        totalmark = "Insert into results values('"+enrollment+"','"+semester+"','"+sp2+"','"+totalpmark2+"','"+grp2+"','"+status+"')";
        db.stmt.executeUpdate(totalmark);
        insertp = "Insert into practicalmarks values('"+enrollment+"','"+semester+"','"+sp3+"','"+sep3+"','"+smp3+"','"+sap1+"')";
        db.stmt.executeUpdate(insertp);
        if(totalpmark3 > 20)
            status = "Pass";
        else
            status = "Fail";
        totalmark = "Insert into results values('"+enrollment+"','"+semester+"','"+sp3+"','"+totalpmark3+"','"+grp3+"','"+status+"')";
        db.stmt.executeUpdate(totalmark);
        insertp = "Insert into practicalmarks values('"+enrollment+"','"+semester+"','"+sp4+"','"+sep4+"','"+smp4+"','"+sap1+"')";
        db.stmt.executeUpdate(insertp);
        if(totalpmark4 > 20)
            status = "Pass";
        else
            status = "Fail";
        totalmark = "Insert into results values('"+enrollment+"','"+semester+"','"+sp4+"','"+totalpmark4+"','"+grp4+"','"+status+"')";
        db.stmt.executeUpdate(totalmark);
        insertp = "Insert into practicalmarks values('"+enrollment+"','"+semester+"','"+sp5+"','"+sep5+"','"+smp5+"','"+sap5+"')";
        db.stmt.executeUpdate(insertp);
        if(totalpmark5 > 20)
            status = "Pass";
        else
            status = "Fail";
        totalmark = "Insert into results values('"+enrollment+"','"+semester+"','"+sp5+"','"+totalpmark5+"','"+grp5+"','"+status+"')";
        db.stmt.executeUpdate(totalmark);
        insertp = "Insert into practicalmarks values('"+enrollment+"','"+semester+"','"+sp6+"','"+sep6+"','"+smp6+"','"+sap6+"')";
        db.stmt.executeUpdate(insertp);
        if(totalpmark6 > 20)
            status = "Pass";
        else
            status = "Fail";
        totalmark = "Insert into results values('"+enrollment+"','"+semester+"','"+sp6+"','"+totalpmark6+"','"+grp6+"','"+status+"')";
        db.stmt.executeUpdate(totalmark);
        
        }catch(Exception e){System.out.println(e);}
        try{
            String sqlcmd = "update students set semester='"+(Integer.parseInt(semester)+1)+"'where enrollment='"+enrollment+"'";
        db2.stmt.executeUpdate(sqlcmd);
        System.out.println(sqlcmd);
        }catch(Exception exp){System.out.println(exp);}
   JOptionPane.showMessageDialog(null, "Data Enter Successfully.");
   enroll.setText("");
   semesterTF.setText(null);
   ettf1.setText("");
   ettf2.setText("");
   ettf3.setText("");
   ettf4.setText("");
   ettf5.setText("");
   mttf1.setText("");
   mttf2.setText("");
   mttf3.setText("");
   mttf4.setText("");
   mttf5.setText("");
   attf1.setText("");
   attf2.setText("");
   attf3.setText("");
   attf4.setText("");
   attf5.setText("");
   eptf1.setText(null);
   eptf2.setText(null);
   eptf3.setText(null);
   eptf4.setText(null);
   eptf5.setText(null);
   aptf1.setText(null);
   aptf2.setText(null);
   aptf3.setText(null);
   aptf4.setText(null);
   aptf5.setText(null);
   lptf1.setText(null);
   lptf2.setText(null);
   lptf3.setText(null);
   lptf4.setText(null);
   lptf5.setText(null);
   t1.setText(null);
   t2.setText(null);
   t3.setText(null);
   t4.setText(null);
   t5.setText(null);
   gt1.setText(null);
   gt2.setText(null);
   gt3.setText(null);
   gt4.setText(null);
   gt5.setText(null);
   tfp1.setText(null);
   tfp2.setText(null);
   tfp3.setText(null);
   tfp4.setText(null);
   tfp5.setText(null);
   gp1.setText(null);
   gp2.setText(null);
   gp3.setText(null);
   gp4.setText(null);
   gp5.setText(null);
   //if(Integer.parseInt(sm)>2){
       eptf6.setText(null);
       aptf6.setText(null);
       lptf6.setText(null);
       tfp6.setText(null);
       gp6.setText(null);
   //}
   
          
    }//GEN-LAST:event_jButton5ActionPerformed
    
    public String gradeTCal(int total){
        String grade;
        if(total >= 91 && total <= 100)
        {grade = "A+,10";}
        else if (total >= 81 && total <= 90)
        { grade = "A,9";}
        else if (total >= 71 && total <= 80)
        {grade = "B+,8";}
        else if (total >= 61 && total <= 70)
        {grade = "B,7";}
        else if (total >= 51 && total <= 60)
        {grade = "C+,6";}
        else if (total >= 41 && total <= 50)
        {grade = "C,5";}
        else 
        {grade = "F,0";}
        return grade;
    }
    public String gradePCal(int total){
        String grade;
        if(total >= 46 && total <= 50)
        {grade = "A+,10";}
        else if (total >= 41 && total <= 45)
        {grade = "A,9";}
        else if (total >= 36 && total <= 40)
        {grade = "B+,8";}
        else if (total >= 31 && total <= 35)
        {grade = "B,7";}
        else if (total >= 26 && total <= 30)
        {grade = "C+,6";}
        else if (total >= 21 && total <= 25)
        {grade = "C,5";}
        else 
        {grade = "F,0";}
        return grade;
    }
   
public int gradCalc(String ss)
{
        int t = ss.indexOf(",");
        String s=ss.substring(t+1,ss.length());
        int tv = Integer.parseInt(s);
        System.out.println(tv);
        return tv;
}
    
    public void sub1Theo()
    {
        set1 = ettf1.getText();
        smt1 = mttf1.getText();
        sat1 = attf1.getText();    
        totaltmark1 = Integer.parseInt(smt1) + Integer.parseInt(sat1) 
                 + Integer.parseInt(set1);
        t1.setText(""+totaltmark1);
        grt1 = gradeTCal(totaltmark1);
        tt1=gradCalc(grt1);        
        gt1.setText(grt1);
    }
    public void sub2Theo(){
        set2 = ettf2.getText();
        smt2 = mttf2.getText();
        sat2 = attf2.getText();
        totaltmark2 = Integer.parseInt(set2) + Integer.parseInt(smt2)
                + Integer.parseInt(sat2) ;
        t2.setText(""+totaltmark2);
        grt2 = gradeTCal(totaltmark2);
        gt2.setText(grt2);
        tt2=gradCalc(grt2);
    }
    public void sub3Theo(){
        set3 = ettf3.getText();
        smt3 = mttf3.getText();
        sat3 = attf3.getText();
        totaltmark3 = Integer.parseInt(set3) + Integer.parseInt(smt3)
                + Integer.parseInt(sat3);
        t3.setText(""+totaltmark3);
        grt3 = gradeTCal(totaltmark3);
        gt3.setText(grt3);
        tt3=gradCalc(grt3);
    }
    public void sub4Theo(){
        set4 = ettf4.getText();
        smt4 = mttf4.getText();
        sat4 = attf4.getText();
        totaltmark4 = Integer.parseInt(set4)+Integer.parseInt(smt4)
                +Integer.parseInt(sat4);
        t4.setText(""+totaltmark4);
        grt4 = gradeTCal(totaltmark4);
        gt4.setText(grt4);
        tt4=gradCalc(grt4);
    }
    public void sub5Theo(){
        set5 = ettf5.getText();        
        smt5 = mttf5.getText();        
        sat5 = attf5.getText();
        totaltmark5 = Integer.parseInt(set5)+Integer.parseInt(smt5)+
                Integer.parseInt(sat5);
        t5.setText(""+totaltmark5);
        grt5 = gradeTCal(totaltmark5);
        gt5.setText(grt5);
        tt5=gradCalc(grt5);
    }
    
    public void sub1Prac(){          
          sep1 = eptf1.getText();
          smp1 = lptf1.getText();
          sap1 = aptf1.getText();
          totalpmark1 = Integer.parseInt(sep1)+ Integer.parseInt(smp1) + 
                  Integer.parseInt(sap1);
          tfp1.setText(""+totalpmark1);    
          grp1 = gradePCal(totalpmark1);
          gp1.setText(grp1);
          tp1=gradCalc(grp1);
    }
    public void sub2Prac(){
        sep2 = eptf2.getText();
          smp2 = lptf2.getText();
          sap2 = aptf2.getText();
          totalpmark2 = Integer.parseInt(sep2)+ Integer.parseInt(smp2) + 
                  Integer.parseInt(sap2);
          tfp2.setText(""+totalpmark2);
          grp2 = gradePCal(totalpmark2);
          gp2.setText(grp2);
          tp2=gradCalc(grp2);
    }
    public void sub3Prac(){
        sep3 = eptf3.getText();
          smp3 = lptf3.getText();
          sap3 = aptf3.getText();
          totalpmark3 = Integer.parseInt(sep3)+ Integer.parseInt(smp3) + 
                  Integer.parseInt(sap3);
          tfp3.setText(""+totalpmark3);
          grp3 = gradePCal(totalpmark3);
          gp3.setText(grp3);
          tp3=gradCalc(grp3);
    }
    public void sub4Prac(){
        sep4 = eptf4.getText();
          smp4 = lptf4.getText();
          sap4 = aptf4.getText();          
          totalpmark4 = Integer.parseInt(sep4)+ Integer.parseInt(smp4) + 
                  Integer.parseInt(sap4);
          tfp4.setText(""+totalpmark4);
          grp4 = gradePCal(totalpmark4);
          gp4.setText(grp4);
          tp4=gradCalc(grp4);
    }
    public void sub5Prac(){
        sep5 = eptf5.getText();
          smp5 = lptf5.getText();
          sap5 = aptf5.getText();
          totalpmark5 = Integer.parseInt(sep5)+ Integer.parseInt(smp5) + 
                  Integer.parseInt(sap5);
          tfp5.setText(""+totalpmark5);
          grp5 = gradePCal(totalpmark5);
          gp5.setText(grp5);
          tp5=gradCalc(grp5);
    }
    public void sub6Prac(){
        sep6 = eptf6.getText();          
          smp6 = lptf6.getText();          
          sap6 = aptf6.getText();
          totalpmark6 = Integer.parseInt(sep6)+ Integer.parseInt(smp6) + 
                  Integer.parseInt(sap6);          
          tfp6.setText(""+totalpmark6);
          grp6 = gradePCal(totalpmark6);
          gp6.setText(grp6);
          tp6=gradCalc(grp6);
    }
    public void SGPA(){
        //SGPA calculation.................................................................
        int temp1,temp2;
        temp1 = (tt1*4) + (tt2*4) + (tt3*4) + (tt4*4) + (tt5*4);
        temp2 = (tp1*2) + (tp2*2) + (tp3*2) + (tp4*2) + (tp5*2) + (tp6*2);
        sgpa = (float)(temp1 + temp2)/32;
        //System.out.println(sgpa);
        String cmd = "insert into finalresult values('"+enrollment+"','"+semester+"','"+sgpa+"','')";
        //System.out.println(cmd);
        try{
        db.stmt.executeUpdate(cmd);
        }catch(Exception ex){System.out.println(ex);}
    }
// CGPA calculation.....................................................................................
public void CGPA(){
    String cgpacmd = "select * from finalresult where enrollment ='"+enrollment+"'";
    float cgptemp = 0.0f;
    int nc = 0;
    try{
        db.rs = db.stmt.executeQuery(cgpacmd);
        //System.out.println(cgpacmd);
        while(db.rs.next()){
            int s = Integer.parseInt(db.rs.getString(2));
            switch(s){
                case 1: cgptemp = cgptemp + Float.parseFloat(db.rs.getString(3))*30;
                        nc = nc + 30;
                        break;
                case 2: cgptemp = cgptemp + Float.parseFloat(db.rs.getString(3))*30;
                        nc = nc + 30;
                        break;
                case 3: cgptemp = cgptemp + Float.parseFloat(db.rs.getString(3))*32;
                        nc = nc + 32;
                        break;
                case 4: cgptemp = cgptemp + Float.parseFloat(db.rs.getString(3))*32;
                        nc = nc + 32;
                        break;
                case 5: cgptemp = cgptemp + Float.parseFloat(db.rs.getString(3))*32;
                        nc = nc + 32;
                        break;
                case 6: cgptemp = cgptemp + Float.parseFloat(db.rs.getString(3))*32;
                        nc = nc + 32;
                        break;
                case 7: cgptemp = cgptemp + Float.parseFloat(db.rs.getString(3))*32;
                        nc = nc + 32;
                        break;
                case 8: cgptemp = cgptemp + Float.parseFloat(db.rs.getString(3))*32;
                        nc = nc + 32;
                        break;        
            }
        }
        float cgpa = (cgptemp / nc);
       // System.out.println(cgpa);
        String update = "update finalresult set cgpa ='"+cgpa+"' where enrollment='"+enrollment+"' and semester='"+semester+"'";
        System.out.println(update);
        
            db.stmt.executeUpdate(update);
            //System.out.println("Inside second try ");
        
    }catch(SQLException | NumberFormatException exp){System.out.println(exp);}
        
    }
    private void enrollFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_enrollFocusLost
//subjectShow();
    }//GEN-LAST:event_enrollFocusLost

    private void enrollKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_enrollKeyReleased
subjectShow();  
    }//GEN-LAST:event_enrollKeyReleased

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
        this.dispose();
    }//GEN-LAST:event_jButton4ActionPerformed

    private void ettf1KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ettf1KeyReleased
        try{
        int a = Integer.parseInt(ettf1.getText());
        if(a > 70){
            JOptionPane.showMessageDialog(null,"Enter Valid Marks!!");
            ettf1.setText(null);
        }
        }catch(NumberFormatException | HeadlessException e){
                       
        } 

try{
    String s = ettf1.getText();
    if(s==null){
    }
    else{
        sub1Theo();
    }    
}catch (Exception e){
t1.setText("");} 
    
    }//GEN-LAST:event_ettf1KeyReleased

    private void mttf1KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_mttf1KeyReleased
        try{
        int a = Integer.parseInt(mttf1.getText());
        if(a > 20){
            JOptionPane.showMessageDialog(null,"Enter Valid Marks!!");
            mttf1.setText(null);
        }
        }catch(NumberFormatException | HeadlessException e){
                       
        } 
     try{
         String s = mttf1.getText();
         if(s == null)
         {}
         else
             sub1Theo();
     }catch(Exception e){
         t1.setText("");
     }
        // TODO add your handling code here:
    }//GEN-LAST:event_mttf1KeyReleased

    private void attf1KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_attf1KeyReleased
        try{
        int a = Integer.parseInt(attf1.getText());
        if(a > 10){
            JOptionPane.showMessageDialog(null,"Enter Valid Marks!!");
            attf1.setText(null);
        }
        }catch(NumberFormatException | HeadlessException e){
                       
        } 
        try{
         String s = attf1.getText();
         if(s == null)
         {}
         else
             sub1Theo();
     }catch(Exception e){
         t1.setText("");
     }
        
    }//GEN-LAST:event_attf1KeyReleased

    private void ettf2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ettf2ActionPerformed

   // sub1Theo();    // TODO add your handling code here:
    }//GEN-LAST:event_ettf2ActionPerformed

    private void mttf2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mttf2ActionPerformed
        // TODO add your handling code here:
      //  sub1Theo();
    }//GEN-LAST:event_mttf2ActionPerformed

    private void attf2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_attf2ActionPerformed
        // TODO add your handling code here:
       // sub1Theo();
    }//GEN-LAST:event_attf2ActionPerformed

    private void mttf3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mttf3ActionPerformed
        // TODO add your handling code here:
       
    }//GEN-LAST:event_mttf3ActionPerformed

    private void attf3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_attf3ActionPerformed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_attf3ActionPerformed

    private void ettf4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ettf4ActionPerformed
        // TODO add your handling code here:
       
    }//GEN-LAST:event_ettf4ActionPerformed

    private void mttf4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mttf4ActionPerformed
        // TODO add your handling code here:

    }//GEN-LAST:event_mttf4ActionPerformed

    private void attf4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_attf4ActionPerformed
        // TODO add your handling code here:
 
    }//GEN-LAST:event_attf4ActionPerformed

    private void ettf5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ettf5ActionPerformed
        // TODO add your handling code here:
      
    }//GEN-LAST:event_ettf5ActionPerformed

    private void mttf5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mttf5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_mttf5ActionPerformed

    private void ettf2KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ettf2KeyReleased
        try{
        int a = Integer.parseInt(ettf2.getText());
        if(a > 70){
            JOptionPane.showMessageDialog(null,"Enter Valid Marks!!");
            ettf2.setText(null);
        }
        }catch(NumberFormatException | HeadlessException e){
                 System.out.println(e);      
        } 
        try{
         String s = ettf2.getText();
         if(s == null)
         {}
         else
             sub2Theo();
     }catch(Exception e){
         t2.setText("");
     }
    }//GEN-LAST:event_ettf2KeyReleased

    private void mttf2KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_mttf2KeyReleased
        try{
        int a = Integer.parseInt(mttf2.getText());
        if(a > 20){
            JOptionPane.showMessageDialog(null,"Enter Valid Marks!!");
            mttf2.setText(null);
        }
        }catch(NumberFormatException | HeadlessException e){
                 System.out.println(e);      
        } 
        try{
         String s = mttf2.getText();
         if(s == null)
         {}
         else
             sub2Theo();
     }catch(Exception e){
         t2.setText("");
     } 
    }//GEN-LAST:event_mttf2KeyReleased

    private void attf2KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_attf2KeyReleased
        try{
        int a = Integer.parseInt(attf2.getText());
        if(a > 10){
            JOptionPane.showMessageDialog(null,"Enter Valid Marks!!");
            attf2.setText(null);
        }
        }catch(NumberFormatException | HeadlessException e){
                 System.out.println(e);      
        } 
        try{
         String s = attf2.getText();
         if(s == null)
         {}
         else
             sub2Theo();
     }catch(Exception e){
         t2.setText("");
     }
    }//GEN-LAST:event_attf2KeyReleased

    private void ettf3KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ettf3KeyReleased
        try{
        int a = Integer.parseInt(ettf3.getText());
        if(a > 70){
            JOptionPane.showMessageDialog(null,"Enter Valid Marks!!");
            ettf3.setText(null);
        }
        }catch(NumberFormatException | HeadlessException e){
                 System.out.println(e);      
        } 
         try{
         String s = ettf3.getText();
         if(s == null)
         {}
         else
             sub3Theo();
     }catch(Exception e){
         t3.setText("");
     }
    }//GEN-LAST:event_ettf3KeyReleased

    private void mttf3KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_mttf3KeyReleased
        try{
        int a = Integer.parseInt(mttf3.getText());
        if(a > 20){
            JOptionPane.showMessageDialog(null,"Enter Valid Marks!!");
            mttf3.setText(null);
        }
        }catch(NumberFormatException | HeadlessException e){
                 System.out.println(e);      
        } 
        try{
         String s = mttf3.getText();
         if(s == null)
         {}
         else
             sub3Theo();
     }catch(Exception e){
         t3.setText("");
     }
    }//GEN-LAST:event_mttf3KeyReleased

    private void attf3KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_attf3KeyReleased
        try{
        int a = Integer.parseInt(attf3.getText());
        if(a > 10){
            JOptionPane.showMessageDialog(null,"Enter Valid Marks!!");
            attf3.setText(null);
        }
        }catch(NumberFormatException | HeadlessException e){
                 System.out.println(e);      
        } 
        try{
         String s = attf3.getText();
         if(s == null)
         {}
         else
             sub3Theo();
     }catch(Exception e){
         t3.setText("");
     }
    }//GEN-LAST:event_attf3KeyReleased

    private void ettf4KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ettf4KeyReleased
       try{
        int a = Integer.parseInt(ettf4.getText());
        if(a > 70){
            JOptionPane.showMessageDialog(null,"Enter Valid Marks!!");
            ettf4.setText(null);
        }
        }catch(NumberFormatException | HeadlessException e){
                 System.out.println(e);      
        } 
        try{
         String s = ettf4.getText();
         if(s == null)
         {}
         else
             sub4Theo();
     }catch(Exception e){
         t4.setText("");
     }
    }//GEN-LAST:event_ettf4KeyReleased

    private void mttf4KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_mttf4KeyReleased
        try{
        int a = Integer.parseInt(mttf4.getText());
        if(a > 20){
            JOptionPane.showMessageDialog(null,"Enter Valid Marks!!");
            mttf4.setText(null);
        }
        }catch(NumberFormatException | HeadlessException e){
                 System.out.println(e);      
        } 
        try{
         String s = mttf4.getText();
         if(s == null)
         {}
         else
             sub4Theo();
     }catch(Exception e){
         t4.setText("");
     }
    }//GEN-LAST:event_mttf4KeyReleased

    private void attf4KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_attf4KeyReleased
        try{
        int a = Integer.parseInt(attf4.getText());
        if(a > 10){
            JOptionPane.showMessageDialog(null,"Enter Valid Marks!!");
            attf4.setText(null);
        }
        }catch(NumberFormatException | HeadlessException e){
                 System.out.println(e);      
        } 
        try{
         String s = attf4.getText();
         if(s == null)
         {}
         else
             sub4Theo();
     }catch(Exception e){
         t4.setText("");
     }
    }//GEN-LAST:event_attf4KeyReleased

    private void ettf5KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ettf5KeyReleased
        try{
        int a = Integer.parseInt(ettf5.getText());
        if(a > 70){
            JOptionPane.showMessageDialog(null,"Enter Valid Marks!!");
            ettf5.setText(null);
        }
        }catch(NumberFormatException | HeadlessException e){
                 System.out.println(e);      
        } 
        try{
         String s = ettf5.getText();
         if(s == null)
         {}
         else
             sub5Theo();
     }catch(Exception e){
         t5.setText("");
     }
    }//GEN-LAST:event_ettf5KeyReleased

    private void mttf5KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_mttf5KeyReleased
        try{
        int a = Integer.parseInt(mttf5.getText());
        if(a > 20){
            JOptionPane.showMessageDialog(null,"Enter Valid Marks!!");
            mttf5.setText(null);
        }
        }catch(NumberFormatException | HeadlessException e){
                 System.out.println(e);      
        } 
        try{
         String s = mttf5.getText();
         if(s == null)
         {}
         else
             sub5Theo();
     }catch(Exception e){
         t5.setText("");
     }
    }//GEN-LAST:event_mttf5KeyReleased

    private void attf5KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_attf5KeyReleased
        try{
        int a = Integer.parseInt(attf5.getText());
        if(a > 10){
            JOptionPane.showMessageDialog(null,"Enter Valid Marks!!");
            attf5.setText(null);
        }
        }catch(NumberFormatException | HeadlessException e){
                 System.out.println(e);      
        } 
        try{
         String s = attf5.getText();
         if(s == null)
         {}
         else
             sub5Theo();
     }catch(Exception e){
         t5.setText("");
     }
    }//GEN-LAST:event_attf5KeyReleased

    private void eptf1KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_eptf1KeyReleased
        try{
        int a = Integer.parseInt(eptf1.getText());
        if(a > 30){
            JOptionPane.showMessageDialog(null,"Enter Valid Marks!!");
            eptf1.setText(null);
        }
        }catch(NumberFormatException | HeadlessException e){
                 System.out.println(e);      
        } 
        try{
         String s = eptf1.getText();
         if(s == null)
         {}
         else
             sub1Prac();
     }catch(Exception e){
         tfp1.setText("");
     }
    }//GEN-LAST:event_eptf1KeyReleased

    private void lptf1KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_lptf1KeyReleased
        try{
        int a = Integer.parseInt(lptf1.getText());
        if(a > 10){
            JOptionPane.showMessageDialog(null,"Enter Valid Marks!!");
            lptf1.setText(null);
        }
        }catch(NumberFormatException | HeadlessException e){
                 System.out.println(e);      
        } 
        try{
         String s = lptf1.getText();
         if(s == null)
         {}
         else
             sub1Prac();
     }catch(Exception e){
         tfp1.setText("");
     }

    }//GEN-LAST:event_lptf1KeyReleased

    private void aptf1KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_aptf1KeyReleased
        try{
        int a = Integer.parseInt(aptf1.getText());
        if(a > 10){
            JOptionPane.showMessageDialog(null,"Enter Valid Marks!!");
            aptf1.setText(null);
        }
        }catch(NumberFormatException | HeadlessException e){
                 System.out.println(e);      
        } 
        try{
         String s = aptf1.getText();
         if(s == null)
         {}
         else
             sub1Prac();
     }catch(Exception e){
         tfp1.setText("");
     }

    }//GEN-LAST:event_aptf1KeyReleased

    private void eptf2KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_eptf2KeyReleased
        try{
        int a = Integer.parseInt(eptf2.getText());
        if(a > 30){
            JOptionPane.showMessageDialog(null,"Enter Valid Marks!!");
            eptf2.setText(null);
        }
        }catch(NumberFormatException | HeadlessException e){
                 System.out.println(e);      
        } 
        try{
         String s = eptf2.getText();
         if(s == null)
         {}
         else
             sub2Prac();
     }catch(Exception e){
         tfp2.setText("");
     }
    }//GEN-LAST:event_eptf2KeyReleased

    private void lptf2KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_lptf2KeyReleased
        try{
        int a = Integer.parseInt(lptf2.getText());
        if(a > 10){
            JOptionPane.showMessageDialog(null,"Enter Valid Marks!!");
            lptf2.setText(null);
        }
        }catch(NumberFormatException | HeadlessException e){
                 System.out.println(e);      
        } 

        try{
         String s = lptf2.getText();
         if(s == null)
         {}
         else
             sub2Prac();
     }catch(Exception e){
         tfp2.setText("");
     }
    }//GEN-LAST:event_lptf2KeyReleased

    private void aptf2KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_aptf2KeyReleased
        try{
        int a = Integer.parseInt(aptf2.getText());
        if(a > 10){
            JOptionPane.showMessageDialog(null,"Enter Valid Marks!!");
            aptf2.setText(null);
        }
        }catch(NumberFormatException | HeadlessException e){
                 System.out.println(e);      
        } 

        try{
         String s = aptf2.getText();
         if(s == null)
         {}
         else
             sub2Prac();
     }catch(Exception e){
         tfp2.setText("");
     }
    }//GEN-LAST:event_aptf2KeyReleased

    private void eptf3KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_eptf3KeyReleased
        try{
        int a = Integer.parseInt(eptf3.getText());
        if(a > 30){
            JOptionPane.showMessageDialog(null,"Enter Valid Marks!!");
            eptf3.setText(null);
        }
        }catch(NumberFormatException | HeadlessException e){
                 System.out.println(e);      
        } 

        try{
         String s = eptf3.getText();
         if(s == null)
         {}
         else
             sub3Prac();
     }catch(Exception e){
         tfp3.setText("");
     }
    }//GEN-LAST:event_eptf3KeyReleased

    private void lptf3KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_lptf3KeyReleased
        try{
        int a = Integer.parseInt(lptf3.getText());
        if(a > 10){
            JOptionPane.showMessageDialog(null,"Enter Valid Marks!!");
            lptf3.setText(null);
        }
        }catch(NumberFormatException | HeadlessException e){
                 System.out.println(e);      
        } 
        try{
         String s = lptf3.getText();
         if(s == null)
         {}
         else
             sub3Prac();
     }catch(Exception e){
         tfp3.setText("");
     }

    }//GEN-LAST:event_lptf3KeyReleased

    private void aptf3KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_aptf3KeyReleased
        try{
        int a = Integer.parseInt(aptf3.getText());
        if(a > 10){
            JOptionPane.showMessageDialog(null,"Enter Valid Marks!!");
            aptf3.setText(null);
        }
        }catch(NumberFormatException | HeadlessException e){
                 System.out.println(e);      
        } 
        try{
         String s = aptf3.getText();
         if(s == null)
         {}
         else
             sub3Prac();
     }catch(Exception e){
         tfp3.setText("");
     }

    }//GEN-LAST:event_aptf3KeyReleased

    private void eptf4KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_eptf4KeyReleased
        try{
        int a = Integer.parseInt(eptf4.getText());
        if(a > 30){
            JOptionPane.showMessageDialog(null,"Enter Valid Marks!!");
            eptf4.setText(null);
        }
        }catch(NumberFormatException | HeadlessException e){
                 System.out.println(e);      
        } 
        try{
         String s = eptf4.getText();
         if(s == null)
         {}
         else
             sub4Prac();
     }catch(Exception e){
         tfp4.setText("");
     }
    }//GEN-LAST:event_eptf4KeyReleased

    private void lptf4KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_lptf4KeyReleased
        try{
        int a = Integer.parseInt(lptf4.getText());
        if(a > 10){
            JOptionPane.showMessageDialog(null,"Enter Valid Marks!!");
            lptf4.setText(null);
        }
        }catch(NumberFormatException | HeadlessException e){
                 System.out.println(e);      
        } 
        try{
         String s = lptf4.getText();
         if(s == null)
         {}
         else
             sub4Prac();
     }catch(Exception e){
         tfp4.setText("");
     }
    }//GEN-LAST:event_lptf4KeyReleased

    private void aptf4KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_aptf4KeyReleased
        try{
        int a = Integer.parseInt(aptf4.getText());
        if(a > 10){
            JOptionPane.showMessageDialog(null,"Enter Valid Marks!!");
            aptf4.setText(null);
        }
        }catch(NumberFormatException | HeadlessException e){
                 System.out.println(e);      
        } 
        try{
         String s = aptf4.getText();
         if(s == null)
         {}
         else
             sub4Prac();
     }catch(Exception e){
         tfp4.setText("");
     }
    }//GEN-LAST:event_aptf4KeyReleased

    private void eptf5KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_eptf5KeyReleased
        try{
        int a = Integer.parseInt(eptf5.getText());
        if(a > 30){
            JOptionPane.showMessageDialog(null,"Enter Valid Marks!!");
            eptf5.setText(null);
        }
        }catch(NumberFormatException | HeadlessException e){
                 System.out.println(e);      
        } 
        try{
         String s = eptf5.getText();
         if(s == null)
         {}
         else
             sub5Prac();
     }catch(Exception e){
         tfp5.setText("");
     }
    }//GEN-LAST:event_eptf5KeyReleased

    private void lptf5KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_lptf5KeyReleased
        try{
        int a = Integer.parseInt(lptf5.getText());
        if(a > 10){
            JOptionPane.showMessageDialog(null,"Enter Valid Marks!!");
            lptf5.setText(null);
        }
        }catch(NumberFormatException | HeadlessException e){
                 System.out.println(e);      
        } 
        try{
         String s = lptf5.getText();
         if(s == null)
         {}
         else
             sub5Prac();
     }catch(Exception e){
         tfp5.setText("");
     }
    }//GEN-LAST:event_lptf5KeyReleased

    private void aptf5KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_aptf5KeyReleased
        try{
        int a = Integer.parseInt(aptf5.getText());
        if(a > 10){
            JOptionPane.showMessageDialog(null,"Enter Valid Marks!!");
            aptf5.setText(null);
        }
        }catch(NumberFormatException | HeadlessException e){
                 System.out.println(e);      
        } 
        try{
         String s = aptf5.getText();
         if(s == null)
         {}
         else
             sub5Prac();
     }catch(Exception e){
         tfp5.setText("");
     }
    }//GEN-LAST:event_aptf5KeyReleased

    private void eptf6KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_eptf6KeyReleased
        try{
        int a = Integer.parseInt(eptf6.getText());
        if(a > 30){
            JOptionPane.showMessageDialog(null,"Enter Valid Marks!!");
            eptf6.setText(null);
        }
        }catch(NumberFormatException | HeadlessException e){
                 System.out.println(e);      
        } 
        try{
         String s = eptf6.getText();
         if(s == null)
         {}
         else
             sub6Prac();
     }catch(Exception e){
         tfp6.setText("");
     }
    }//GEN-LAST:event_eptf6KeyReleased

    private void lptf6KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_lptf6KeyReleased
        try{
        int a = Integer.parseInt(lptf6.getText());
        if(a > 10){
            JOptionPane.showMessageDialog(null,"Enter Valid Marks!!");
            lptf6.setText(null);
        }
        }catch(NumberFormatException | HeadlessException e){
                 System.out.println(e);      
        } 
        try{
         String s = lptf6.getText();
         if(s == null)
         {}
         else
             sub6Prac();
     }catch(Exception e){
         tfp6.setText("");
     }
    }//GEN-LAST:event_lptf6KeyReleased

    private void aptf6KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_aptf6KeyReleased
        try{
        int a = Integer.parseInt(aptf6.getText());
        if(a > 10){
            JOptionPane.showMessageDialog(null,"Enter Valid Marks!!");
            aptf6.setText(null);
        }
        }catch(NumberFormatException | HeadlessException e){
                 System.out.println(e);      
        } 
        try{
         String s = aptf6.getText();
         if(s == null)
         {}
         else
             sub6Prac();
     }catch(Exception e){
         tfp6.setText("");
     }
    }//GEN-LAST:event_aptf6KeyReleased

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ResultsEntry.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ResultsEntry.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ResultsEntry.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ResultsEntry.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                ResultsEntry dialog = new ResultsEntry(new javax.swing.JDialog(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Grade;
    private javax.swing.JTextField aptf1;
    private javax.swing.JTextField aptf2;
    private javax.swing.JTextField aptf3;
    private javax.swing.JTextField aptf4;
    private javax.swing.JTextField aptf5;
    private javax.swing.JTextField aptf6;
    private javax.swing.JTextField attf1;
    private javax.swing.JTextField attf2;
    private javax.swing.JTextField attf3;
    private javax.swing.JTextField attf4;
    private javax.swing.JTextField attf5;
    private javax.swing.JTextField enroll;
    private javax.swing.JTextField eptf1;
    private javax.swing.JTextField eptf2;
    private javax.swing.JTextField eptf3;
    private javax.swing.JTextField eptf4;
    private javax.swing.JTextField eptf5;
    private javax.swing.JTextField eptf6;
    private javax.swing.JTextField ettf1;
    private javax.swing.JTextField ettf2;
    private javax.swing.JTextField ettf3;
    private javax.swing.JTextField ettf4;
    private javax.swing.JTextField ettf5;
    private javax.swing.JLabel gp1;
    private javax.swing.JLabel gp2;
    private javax.swing.JLabel gp3;
    private javax.swing.JLabel gp4;
    private javax.swing.JLabel gp5;
    private javax.swing.JLabel gp6;
    private javax.swing.JLabel gt1;
    private javax.swing.JLabel gt2;
    private javax.swing.JLabel gt3;
    private javax.swing.JLabel gt4;
    private javax.swing.JLabel gt5;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel49;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel50;
    private javax.swing.JLabel jLabel51;
    private javax.swing.JLabel jLabel52;
    private javax.swing.JLabel jLabel53;
    private javax.swing.JLabel jLabel54;
    private javax.swing.JLabel jLabel55;
    private javax.swing.JLabel jLabel56;
    private javax.swing.JLabel jLabel57;
    private javax.swing.JLabel jLabel58;
    private javax.swing.JLabel jLabel59;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel60;
    private javax.swing.JLabel jLabel61;
    private javax.swing.JLabel jLabel62;
    private javax.swing.JLabel jLabel63;
    private javax.swing.JLabel jLabel69;
    private javax.swing.JLabel jLabel71;
    private javax.swing.JLabel jLabel72;
    private javax.swing.JLabel jLabel78;
    private javax.swing.JLabel jLabel79;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel80;
    private javax.swing.JLabel jLabel81;
    private javax.swing.JLabel jLabel82;
    private javax.swing.JLabel jLabel83;
    private javax.swing.JLabel jLabel84;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JLabel l1;
    private javax.swing.JLabel l10;
    private javax.swing.JLabel l11;
    private javax.swing.JLabel l2;
    private javax.swing.JLabel l3;
    private javax.swing.JLabel l4;
    private javax.swing.JLabel l5;
    private javax.swing.JLabel l6;
    private javax.swing.JLabel l7;
    private javax.swing.JLabel l8;
    private javax.swing.JLabel l9;
    private javax.swing.JTextField lptf1;
    private javax.swing.JTextField lptf2;
    private javax.swing.JTextField lptf3;
    private javax.swing.JTextField lptf4;
    private javax.swing.JTextField lptf5;
    private javax.swing.JTextField lptf6;
    private javax.swing.JTextField mttf1;
    private javax.swing.JTextField mttf2;
    private javax.swing.JTextField mttf3;
    private javax.swing.JTextField mttf4;
    private javax.swing.JTextField mttf5;
    private javax.swing.JTextField semesterTF;
    private javax.swing.JTextField t1;
    private javax.swing.JTextField t2;
    private javax.swing.JTextField t3;
    private javax.swing.JTextField t4;
    private javax.swing.JTextField t5;
    private javax.swing.JTextField tfp1;
    private javax.swing.JTextField tfp2;
    private javax.swing.JTextField tfp3;
    private javax.swing.JTextField tfp4;
    private javax.swing.JTextField tfp5;
    private javax.swing.JTextField tfp6;
    // End of variables declaration//GEN-END:variables
}
