
package resultanalysis;

import java.awt.event.MouseEvent;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;

public class ResultViewPage extends javax.swing.JDialog {

   DefaultTableModel model;
    Databaseconnection db,db2;
    JDialog jd;
    String clgf,semf,brf,batchf;
    int c = 5;
    String subch;
    String bh;
    public ResultViewPage(javax.swing.JDialog parent, boolean modal , String clg ,String br , String sem ,int b,String batch) {
        super(parent, modal);
        initComponents();
        //tf1.setToolTipText("Enter Enrollment");
        this.setTitle("Result Sheet");
        db = new Databaseconnection();
        db2 = new Databaseconnection();
        c = b;
        clgf = clg;
        brf = br;
        semf = sem;
        batchf = batch;
        model = (DefaultTableModel)table.getModel();
        jd = parent;
        this.setVisible(true);
       
        
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        buttonGroup1 = new javax.swing.ButtonGroup();
        jButton4 = new javax.swing.JButton();
        jRadioButton1 = new javax.swing.JRadioButton();
        jRadioButton4 = new javax.swing.JRadioButton();
        jRadioButton8 = new javax.swing.JRadioButton();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        table = new javax.swing.JTable();
        tf1 = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jButton4.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton4.setText("Cancel");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        buttonGroup1.add(jRadioButton1);
        jRadioButton1.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        jRadioButton1.setText("Top 10");
        jRadioButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton1ActionPerformed(evt);
            }
        });

        buttonGroup1.add(jRadioButton4);
        jRadioButton4.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        jRadioButton4.setText("Subject Wise Top10");
        jRadioButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton4ActionPerformed(evt);
            }
        });

        buttonGroup1.add(jRadioButton8);
        jRadioButton8.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jRadioButton8.setText("All");
        jRadioButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton8ActionPerformed(evt);
            }
        });

        table.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "S.no.", "Enrollment", "Name", "Branch", "Sem", "SGPA", "CGPA", "Status"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        table.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tableMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(table);
        if (table.getColumnModel().getColumnCount() > 0) {
            table.getColumnModel().getColumn(0).setHeaderValue("S.no.");
            table.getColumnModel().getColumn(1).setHeaderValue("Enrollment");
            table.getColumnModel().getColumn(2).setHeaderValue("Name");
            table.getColumnModel().getColumn(3).setHeaderValue("Branch");
            table.getColumnModel().getColumn(4).setHeaderValue("Sem");
            table.getColumnModel().getColumn(5).setHeaderValue("SGPA");
            table.getColumnModel().getColumn(6).setHeaderValue("CGPA");
            table.getColumnModel().getColumn(7).setHeaderValue("Status");
        }

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 577, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        tf1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        tf1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tf1KeyReleased(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel1.setText("Search Result");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(44, 44, 44)
                .addComponent(jRadioButton8)
                .addGap(164, 164, 164)
                .addComponent(jRadioButton1)
                .addGap(202, 202, 202)
                .addComponent(jRadioButton4)
                .addGap(141, 141, 141)
                .addComponent(jLabel1)
                .addGap(70, 70, 70)
                .addComponent(tf1, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(160, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton4)
                .addGap(145, 145, 145))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jRadioButton1)
                    .addComponent(jRadioButton4)
                    .addComponent(jRadioButton8)
                    .addComponent(tf1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 4, Short.MAX_VALUE)
                .addComponent(jButton4))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
        this.dispose();
    }//GEN-LAST:event_jButton4ActionPerformed
public void tableOperation(int i){
    JTableHeader th = table.getTableHeader();
        TableColumnModel tcm = th.getColumnModel();
        TableColumn tc1 = tcm.getColumn(5);
        TableColumn tc2 = tcm.getColumn(6);
        tc1.setHeaderValue("CGPA");
        tc2.setHeaderValue("SGPA");
        th.repaint();
    int rc = model.getRowCount();
        rc = rc - 1;
        while(rc >= 0){
            model.removeRow(rc);
            rc--;
        }
        String cmd = "";
        String cmd1 = "";
        bh = batchf.substring(2,4);
       // System.out.println("Year "+bh);
       
        if( c == 1)
            cmd = "select * from students where college ='"+clgf+"' and enrollment like '______"+bh+"____'";
        if(c == 0)
            cmd = "select * from students where enrollment like '______"+bh+"____'";
    
        try{
            db.rs = db.stmt.executeQuery(cmd);
            int t = 1;
            while(db.rs.next()){
                String s1,s2,s3,s4 = "",s5 ="",s6 = "";
                s1 = db.rs.getString(1);
                s2 = db.rs.getString(3);
                s3 = db.rs.getString(7);
               if(i == 2)
                cmd1 = "select sgpa , cgpa from finalresult where enrollment ='"+s1+"' and semester ='"+semf+"'";
             /*  else if(i == 3)
                   cmd1 = "select sgpa , cgpa from finalresult where enrollment ='"+s1+"'semester ='"+semf+"' order by cgpa desc";
              System.out.println(cmd1);*/
                db2.rs = db2.stmt.executeQuery(cmd1);
                db2.rs.next();
                    s5 = db2.rs.getString(1);
                    s6 = db2.rs.getString(2);
                model.addRow(new Object[] {""+t,s1,s2,s3,semf,s5,s6,"Pass"});
                t++;        
            }
        }catch(Exception ex){
        System.out.println(ex);
        JOptionPane.showMessageDialog(null,"Data not found in Record..!");
        }
}
    
    private void jRadioButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton8ActionPerformed
        tableOperation(2);

    }//GEN-LAST:event_jRadioButton8ActionPerformed

    private void jRadioButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton4ActionPerformed
        Databaseconnection c1,c2;
        c1 = new Databaseconnection();
        c2 = new Databaseconnection();
        int rc = model.getRowCount();
        rc = rc - 1;
        while(rc >= 0){
            model.removeRow(rc);
            rc--;
        }
        JTableHeader th = table.getTableHeader();
        TableColumnModel tcm = th.getColumnModel();
        TableColumn tc1 = tcm.getColumn(5);
        TableColumn tc2 = tcm.getColumn(6);
        tc1.setHeaderValue("Subject_Name");
        tc2.setHeaderValue("Grade");
        th.repaint();
        SubSelection ss = new SubSelection(this,true , semf);
        String sev = ss.ch.substring(0,8);
       // System.out.println(sev);
        subch = sev;
        String cmd1 ="",cmd2="";
        if(c == 0)
         cmd1 = "Select * from results where enrollment like '______"+bh+"____'and semester = '"+semf+"' and sub_code='"+subch+"' order by totalmarks desc ";
        if(c == 1) 
       cmd1 = "Select * from results r , students s where r.enrollment like '______"+bh+"____'and r.semester = '"+semf+"' and r.sub_code='"+subch+"'and s.college='"+clgf+"' and s.enrollment=r.enrollment order by r.totalmarks desc ";
        //System.out.println(cmd1);
        try{
            c1.rs = c1.stmt.executeQuery(cmd1);
            int temp = 1;
            while(c1.rs.next()){
                String en,gr,st,nm,br,subcode;
                en = c1.rs.getString(1);
                gr = c1.rs.getString(5);
                st = c1.rs.getString(6);
                subcode=ss.ch.substring(9,ss.ch.length());
                int t = gr.indexOf(",");
                String s=gr.substring(0,t);
               // if(c == 0)
                cmd2 = "select * from students where enrollment='"+en+"'";
                //if(c == 1)
               //cmd2 = "Select * from students where enrollment='"+en+"'and college='"+clgf+"'";
               //System.out.println(cmd2);
                c2.rs = c2.stmt.executeQuery(cmd2);
                c2.rs.next();
                nm = c2.rs.getString(3);
                br =c2.rs.getString(7);
                model.addRow(new Object[] {""+temp,en,nm,br,semf,subcode,s,st});
                temp++;
            }
        }catch(Exception exo){
        System.out.println(exo);
        JOptionPane.showMessageDialog(null,"Record not Found..");
        }
        
    }//GEN-LAST:event_jRadioButton4ActionPerformed

    private void jRadioButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton1ActionPerformed
   //tableOperation(3);
   Databaseconnection cm1,cm2;
   cm1 = new Databaseconnection();
   cm2 = new Databaseconnection();
   JTableHeader th = table.getTableHeader();
        TableColumnModel tcm = th.getColumnModel();
        TableColumn tc1 = tcm.getColumn(5);
        TableColumn tc2 = tcm.getColumn(6);
        tc1.setHeaderValue("CGPA");
        tc2.setHeaderValue("SGPA");
        th.repaint();
   int rc = model.getRowCount();
        rc = rc - 1;
        while(rc >= 0){
            model.removeRow(rc);
            rc--;
        }
         bh = batchf.substring(2,4);
   String cmd = "" ,cmd1 = "",name ="",brc="";
   if(c == 0)
   cmd = "select * from finalresult where enrollment like '______"+bh+"____'"+" and semester ='"+semf+"' order by cgpa desc";
    if(c ==1 )
    cmd ="select * from finalresult f , students s where s.enrollment like'______"+bh+"____' and s.enrollment = f.enrollment and f.semester='"+semf+"' and s.college='"+clgf+"' order by f.cgpa desc";
          /*select * from finalresult f, students s where s.enrollment like'______13____' and s.enrollment = f.enrollment and f.semester='1' and s.college='0191-Technocrtes Institute Of Technology(EXCELLENCE)' order by f.cgpa desc*/
    //System.out.println(cmd);
   try{
   cm1.rs = cm1.stmt.executeQuery(cmd);
   int temp = 1;
    while(cm1.rs.next()){
        String enrol,sgp,cgp;
        enrol = cm1.rs.getString(1);
        sgp = cm1.rs.getString(3);
        cgp= cm1.rs.getString(4);
        //if(c == 1)
        //cmd1 = "Select * from students s,finalresult f  where f.semester ='"+semf+"' and f.enrollment=s.enrollment and s.college ='"+clgf+"'";
        //if(c == 0)
        cmd1 = "Select * from students where enrollment='"+enrol+"'";
        //System.out.println(cmd1);
        cm2.rs = cm2.stmt.executeQuery(cmd1);
        cm2.rs.next();
        name= cm2.rs.getString(3);
        brc= cm2.rs.getString(7);
        model.addRow(new Object[] {""+temp,enrol,name,brc,semf,sgp,cgp,"pass"});
        temp++;
        //System.out.println(cmd1);
    }
   }catch(Exception exp){System.out.println(exp);
   JOptionPane.showMessageDialog(null,"Record Not found..!");}
    }//GEN-LAST:event_jRadioButton1ActionPerformed
       public void RSearch(){
        JTableHeader th = table.getTableHeader();
        TableColumnModel tcm = th.getColumnModel();
        TableColumn tc1 = tcm.getColumn(5);
        TableColumn tc2 = tcm.getColumn(6);
        tc1.setHeaderValue("CGPA");
        tc2.setHeaderValue("SGPA");
        th.repaint();
        String en = "",cmd1="",cmd2="";
        int rc = model.getRowCount();
        rc = rc - 1;
        while(rc >= 0){
            model.removeRow(rc);
            rc--;
        }
         en = tf1.getText();
        if( c == 1)
            cmd1 = "select * from students where college ='"+clgf+"' and enrollment='"+en+"'";
        if(c == 0)
            cmd1 = "select * from students where enrollment='"+en+"'";
        try{
            db.rs = db.stmt.executeQuery(cmd1);
            int t = 1;
            while(db.rs.next()){
                String s1,s2,s3,s4 = "",s5 ="",s6 = "";
                s2 = db.rs.getString(3);
                s3 = db.rs.getString(7);
                cmd2 = "select sgpa , cgpa from finalresult where enrollment ='"+en+"' and semester ='"+semf+"'";
                db2.rs = db2.stmt.executeQuery(cmd2);
                db2.rs.next();
                    s5 = db2.rs.getString(1);
                    s6 = db2.rs.getString(2);
                model.addRow(new Object[] {""+t,en,s2,s3,semf,s5,s6,"Pass"});
                t++;        
            }
        }catch(Exception ex){
        System.out.println(ex);
        JOptionPane.showMessageDialog(null,"Data not found in Record..!");
        }
    }
    private void tf1KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tf1KeyReleased
        RSearch();
    }//GEN-LAST:event_tf1KeyReleased

    private void tableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tableMouseClicked

        if(evt instanceof MouseEvent){
            int count = ((MouseEvent)evt).getClickCount();
            int previousRow = table.getSelectedRow();
            int previousColumn = table.getSelectedColumn();
            String s1,s2;
            s1=(String)model.getValueAt(previousRow, 1);
            s2=(String)model.getValueAt(previousRow, 4);
            if(previousColumn == 1 && count == 2){
                DetailResult dr = new DetailResult(this,true,s1,s2);
                //dr.setVisible(true);
            }
        }

        // TODO add your handling code here:
    }//GEN-LAST:event_tableMouseClicked

    /**
     * @param args the command line arguments
     */
    //public static void main(String args[]) {
      /*  try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ResultViewPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ResultViewPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ResultViewPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ResultViewPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                ResultViewPage dialog = new ResultViewPage(new javax.swing.JDialog(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }*/

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JRadioButton jRadioButton1;
    private javax.swing.JRadioButton jRadioButton4;
    private javax.swing.JRadioButton jRadioButton8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable table;
    private javax.swing.JTextField tf1;
    // End of variables declaration//GEN-END:variables
}















