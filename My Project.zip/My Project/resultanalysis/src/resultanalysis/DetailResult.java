
package resultanalysis;

import javax.swing.JDialog;

public class DetailResult extends javax.swing.JDialog {
    JDialog jd;
    String enroll,semester;
    public DetailResult(javax.swing.JDialog parent, boolean modal, String en , String sm) {
        super(parent, modal);
        initComponents();
        enroll = en;
        semester = sm;
        if(Integer.parseInt(semester)<3)
                {
        scp6.setVisible(false);
        snp6.setVisible(false);
        tc.setVisible(false);
        p6.setVisible(false);
        gp6.setVisible(false);
                }
        ResultShow();
        jd = parent;
        this.setVisible(true);
    }
public void ResultShow(){
    
    Databaseconnection db1,db2,db3;
    db1 = new Databaseconnection();
    db2 = new Databaseconnection();
    db3 = new Databaseconnection();
    String cmd1;
    String n="",br="",clg="";
    cmd1 = "Select * from students where enrollment='"+enroll+"'";
    try{
        db1.rs = db1.stmt.executeQuery(cmd1);
        while(db1.rs.next()){
          n = db1.rs.getString(3);
          br = db1.rs.getString(7);
          clg = db1.rs.getString(8);
        }
        
    }catch(Exception ep){System.out.print(ep);}
    String cmd2="Select sub_code , grade , status from results where enrollment='"+enroll+"' and semester='"+semester+"' and sub_code like '______T_' order by sub_code";
    //System.out.println(cmd2);
    String cmd3="";
   //select * from subjects s , results r where s.sub_code ='BE202[T]' and s.sub_code = r.sub_code and r.enrollment ='0199cs131084';
    String th1c="",th2c="",th3c="",th4c="",th5c="",th1g="",th2g="",th3g="",th4g="",th5g="",th1s="",th2s="",th3s="",th4s="",th5s="";
    String th1subname="",th2subname="",th3subname="",th4subname="",th5subname="";
    try{
        db2.rs = db2.stmt.executeQuery(cmd2);
        db2.rs.next();
       th1c=db2.rs.getString(1);
       th1g=db2.rs.getString(2);
       th1s=db2.rs.getString(3);
       int t = th1g.indexOf(",");
       th1g = th1g.substring(0,t);
       if(th1s.equals("Pass"))
           th1s="4";
       else
           th1s = "0";
       cmd3="select * from subjects s,results r where s.sub_code='"+th1c+"' and s.sub_code = r.sub_code and r.enrollment ='"+enroll+"'";
       db3.rs = db3.stmt.executeQuery(cmd3);
       db3.rs.next();
       th1subname = db3.rs.getString(3);
       /*System.out.println(th1c);
       System.out.println(th1g);
       System.out.println(th1s);
       System.out.println(th1subname);*/
       db2.rs.next();
       th2c=db2.rs.getString(1);
       th2g=db2.rs.getString(2);
       th2s=db2.rs.getString(3);
       int t2 = th2g.indexOf(",");
       th2g = th2g.substring(0,t2);
       if(th2s.equals("Pass"))
           th2s="4";
       else
           th2s = "0";
       cmd3="select * from subjects s,results r where s.sub_code='"+th2c+"' and s.sub_code = r.sub_code and r.enrollment ='"+enroll+"'";
       db3.rs = db3.stmt.executeQuery(cmd3);
       db3.rs.next();
       th2subname = db3.rs.getString(3);
        db2.rs.next();
       th3c=db2.rs.getString(1);
       th3g=db2.rs.getString(2);
       th3s=db2.rs.getString(3);
       int t3 = th3g.indexOf(",");
       th3g = th3g.substring(0,t3);
       if(th3s.equals("Pass"))
           th3s="4";
       else
           th3s = "0";
       cmd3="select * from subjects s,results r where s.sub_code='"+th3c+"' and s.sub_code = r.sub_code and r.enrollment ='"+enroll+"'";
       db3.rs = db3.stmt.executeQuery(cmd3);
       db3.rs.next();
       th3subname = db3.rs.getString(3);
        db2.rs.next();
       th4c=db2.rs.getString(1);
       th4g=db2.rs.getString(2);
       th4s=db2.rs.getString(3);
       int t4 = th4g.indexOf(",");
       th4g = th4g.substring(0,t4);
       if(th4s.equals("Pass"))
           th4s="4";
       else
           th4s = "0";
       cmd3="select * from subjects s,results r where s.sub_code='"+th4c+"' and s.sub_code = r.sub_code and r.enrollment ='"+enroll+"'";
       db3.rs = db3.stmt.executeQuery(cmd3);
       db3.rs.next();
       th4subname = db3.rs.getString(3);
        db2.rs.next();
       th5c=db2.rs.getString(1);
       th5g=db2.rs.getString(2);
       th5s=db2.rs.getString(3);
       int t5 = th5g.indexOf(",");
       th5g = th5g.substring(0,t5);
       if(th5s.equals("Pass"))
           th5s="4";
       else
           th5s = "0";
       cmd3="select * from subjects s,results r where s.sub_code='"+th5c+"' and s.sub_code = r.sub_code and r.enrollment ='"+enroll+"'";
       db3.rs = db3.stmt.executeQuery(cmd3);
       db3.rs.next();
       th5subname = db3.rs.getString(3);
       
    }catch(Exception e){System.out.println(e);}
    String cmd4="Select sub_code,grade,status from results where enrollment='"+enroll+"' and semester='"+semester+"' and sub_code like '______P_' order by sub_code";
    //System.out.println("cmd4 :-"+cmd4);
    //select sub_code,grade,status from results where enrollment='0199cs131084' and semester='1' and sub_code like '______P_' order by sub_code;
    Databaseconnection db4,db5;
    db4 = new Databaseconnection();
    db5 = new Databaseconnection();
    String pr1c="",pr2c="",pr3c="",pr4c="",pr5c="",pr6c="",pr1g="",pr2g="",pr3g="",pr4g="",pr5g="",pr6g="",pr1s="",pr2s="",pr3s="",pr4s="",pr5s="",pr6s="";
    String pr1subname="",pr2subname="",pr3subname="",pr4subname="",pr5subname="",pr6subname="";
   String cmd5="";
    try{
        db4.rs = db4.stmt.executeQuery(cmd4);
        db4.rs.next();
       pr1c=db4.rs.getString(1);
       pr1g=db4.rs.getString(2);
       pr1s=db4.rs.getString(3);
       int tp1 = pr1g.indexOf(",");
       pr1g = pr1g.substring(0,tp1);
       if(pr1s.equals("Pass"))
           pr1s="2";
       else
           pr1s = "0";
       cmd5="select * from subjects s,results r where s.sub_code='"+pr1c+"' and s.sub_code = r.sub_code and r.enrollment ='"+enroll+"'";
       db5.rs = db5.stmt.executeQuery(cmd5);
       db5.rs.next();
       pr1subname=db5.rs.getString(3);
        db4.rs.next();
        pr2c=db4.rs.getString(1);
       pr2g=db4.rs.getString(2);
       pr2s=db4.rs.getString(3);
       int tp2 = pr2g.indexOf(",");
       pr2g = pr2g.substring(0,tp2);
       if(pr2s.equals("Pass"))
           pr2s="2";
       else
           pr2s = "0";
       cmd5="select * from subjects s,results r where s.sub_code='"+pr2c+"' and s.sub_code = r.sub_code and r.enrollment ='"+enroll+"'";
       db5.rs = db5.stmt.executeQuery(cmd5);
       db5.rs.next();
       pr2subname=db5.rs.getString(3);
        db4.rs.next();
        pr3c=db4.rs.getString(1);
       pr3g=db4.rs.getString(2);
       pr3s=db4.rs.getString(3);
       int tp3 = pr3g.indexOf(",");
       pr3g = pr3g.substring(0,tp3);
       if(pr3s.equals("Pass"))
           pr3s="2";
       else
           pr3s = "0";
       cmd5="select * from subjects s,results r where s.sub_code='"+pr3c+"' and s.sub_code = r.sub_code and r.enrollment ='"+enroll+"'";
       db5.rs = db5.stmt.executeQuery(cmd5);
       db5.rs.next();
       pr3subname=db5.rs.getString(3);
        db4.rs.next();
        pr4c=db4.rs.getString(1);
       pr4g=db4.rs.getString(2);
       pr4s=db4.rs.getString(3);
       int tp4 = pr4g.indexOf(",");
       pr4g = pr4g.substring(0,tp4);
       if(pr4s.equals("Pass"))
           pr4s="2";
       else
           pr4s = "0";
       cmd5="select * from subjects s,results r where s.sub_code='"+pr4c+"' and s.sub_code = r.sub_code and r.enrollment ='"+enroll+"'";
       db5.rs = db5.stmt.executeQuery(cmd5);
       db5.rs.next();
       pr4subname=db5.rs.getString(3);
        db4.rs.next();
       pr5c=db4.rs.getString(1);
       pr5g=db4.rs.getString(2);
       pr5s=db4.rs.getString(3);
       int tp5 = pr5g.indexOf(",");
       pr5g = pr5g.substring(0,tp5);
       if(pr5s.equals("Pass"))
           pr5s="2";
       else
           pr5s = "0";
       cmd5="select * from subjects s,results r where s.sub_code='"+pr5c+"' and s.sub_code = r.sub_code and r.enrollment ='"+enroll+"'";
       //System.out.println(cmd5);
       db5.rs = db5.stmt.executeQuery(cmd5);
       db5.rs.next();
       pr5subname=db5.rs.getString(3);
       //System.out.println(pr5subname);
       if(Integer.parseInt(semester) > 2){
        db4.rs.next();
        pr6c=db4.rs.getString(1);
       pr6g=db4.rs.getString(2);
       pr6s=db4.rs.getString(3);
       int tp6 = pr6g.indexOf(",");
       pr6g = pr6g.substring(0,tp6);
       if(pr6s.equals("Pass"))
           pr6s="2";
       else
           pr6s = "0";
       cmd5="select * from subjects s,results r where s.sub_code='"+pr6c+"' and s.sub_code = r.sub_code and r.enrollment ='"+enroll+"'";
       db5.rs = db5.stmt.executeQuery(cmd5);
       db5.rs.next();
       pr6subname=db5.rs.getString(3);
       }
    }catch(Exception e){System.out.println(e);}
    String cmd6="";
    String sg="",cg="";
    Databaseconnection db6;
    db6 = new Databaseconnection();
    cmd6 ="select sgpa,cgpa from finalresult where enrollment='"+enroll+"' and semester='"+semester+"'";
    try{
       db6.rs = db6.stmt.executeQuery(cmd6);
       db6.rs.next();
       sg = db6.rs.getString(1);
       cg = db6.rs.getString(2);
    }catch(Exception e){System.out.println(e);}
    sct1.setText(th1c);
    sct2.setText(th2c);
    sct3.setText(th3c);
    sct4.setText(th4c);
    sct5.setText(th5c);
    snt1.setText(th1subname);
    snt2.setText(th2subname);
    snt3.setText(th3subname);
    snt4.setText(th4subname);
    t1.setText(th1s);
    t2.setText(th2s);
    t3.setText(th3s);
    t4.setText(th4s);
    t5.setText(th5s);
    gt1.setText(th1g);
    gt2.setText(th2g);
    gt3.setText(th3g);
    gt4.setText(th4g);
    gt5.setText(th5g);
    snt5.setText(th5subname);
    enrollment.setText(enroll);
    name.setText(n);
    branch.setText(br);
    college.setText(clg);
    sem.setText(semester);
    scp1.setText(pr1c);
    scp2.setText(pr2c);
    scp3.setText(pr3c);
    scp4.setText(pr4c);
    scp5.setText(pr5c);
    if(Integer.parseInt(semester)>2)
        scp6.setText(pr6c);
    snp1.setText(pr1subname);
    snp2.setText(pr2subname);
    snp3.setText(pr3subname);
    snp4.setText(pr4subname);
    snp5.setText(pr5subname);
    if(Integer.parseInt(semester)>2)
        snp6.setText(pr6subname);
    p1.setText(pr1s);
    p2.setText(pr2s);
    p3.setText(pr3s);
    p4.setText(pr4s);
    p5.setText(pr5s);
    if(Integer.parseInt(semester)>2)
        p6.setText(pr6s);
    gp1.setText(pr1g);
    gp2.setText(pr2g);
    gp3.setText(pr3g);
    gp4.setText(pr4g);
    gp5.setText(pr5g);
    if(Integer.parseInt(semester)>2)
        gp6.setText(pr6g);
    sgpa.setText(sg);
    cgpa.setText(cg);
}
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        snt1 = new javax.swing.JLabel();
        snt2 = new javax.swing.JLabel();
        snt3 = new javax.swing.JLabel();
        snt4 = new javax.swing.JLabel();
        snt5 = new javax.swing.JLabel();
        snp1 = new javax.swing.JLabel();
        snp2 = new javax.swing.JLabel();
        snp3 = new javax.swing.JLabel();
        snp4 = new javax.swing.JLabel();
        snp5 = new javax.swing.JLabel();
        snp6 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        tc = new javax.swing.JLabel();
        t1 = new javax.swing.JLabel();
        t2 = new javax.swing.JLabel();
        t3 = new javax.swing.JLabel();
        t4 = new javax.swing.JLabel();
        t5 = new javax.swing.JLabel();
        p1 = new javax.swing.JLabel();
        p2 = new javax.swing.JLabel();
        p3 = new javax.swing.JLabel();
        p4 = new javax.swing.JLabel();
        p5 = new javax.swing.JLabel();
        p6 = new javax.swing.JLabel();
        gt1 = new javax.swing.JLabel();
        gt2 = new javax.swing.JLabel();
        gt3 = new javax.swing.JLabel();
        gt4 = new javax.swing.JLabel();
        gt5 = new javax.swing.JLabel();
        gp1 = new javax.swing.JLabel();
        gp2 = new javax.swing.JLabel();
        gp3 = new javax.swing.JLabel();
        gp4 = new javax.swing.JLabel();
        gp5 = new javax.swing.JLabel();
        gp6 = new javax.swing.JLabel();
        sct1 = new javax.swing.JLabel();
        sct2 = new javax.swing.JLabel();
        sct3 = new javax.swing.JLabel();
        sct4 = new javax.swing.JLabel();
        sct5 = new javax.swing.JLabel();
        scp1 = new javax.swing.JLabel();
        scp2 = new javax.swing.JLabel();
        scp3 = new javax.swing.JLabel();
        scp4 = new javax.swing.JLabel();
        scp5 = new javax.swing.JLabel();
        scp6 = new javax.swing.JLabel();
        jLabel61 = new javax.swing.JLabel();
        sgpa = new javax.swing.JLabel();
        jLabel63 = new javax.swing.JLabel();
        cgpa = new javax.swing.JLabel();
        jLabel62 = new javax.swing.JLabel();
        jLabel64 = new javax.swing.JLabel();
        jLabel66 = new javax.swing.JLabel();
        jLabel67 = new javax.swing.JLabel();
        jLabel68 = new javax.swing.JLabel();
        jLabel69 = new javax.swing.JLabel();
        jLabel70 = new javax.swing.JLabel();
        jLabel71 = new javax.swing.JLabel();
        branch = new javax.swing.JLabel();
        sem = new javax.swing.JLabel();
        jLabel74 = new javax.swing.JLabel();
        enrollment = new javax.swing.JLabel();
        name = new javax.swing.JLabel();
        college = new javax.swing.JLabel();
        jLabel78 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Cambria", 1, 12)); // NOI18N
        jLabel1.setText("Subject Code");

        jLabel2.setFont(new java.awt.Font("Cambria", 1, 12)); // NOI18N
        jLabel2.setText("Subject Name");

        jLabel3.setFont(new java.awt.Font("Cambria", 1, 12)); // NOI18N
        jLabel3.setText("Total Credit");

        jLabel4.setFont(new java.awt.Font("Cambria", 1, 12)); // NOI18N
        jLabel4.setText("Earned Credit");

        jLabel5.setFont(new java.awt.Font("Cambria", 1, 12)); // NOI18N
        jLabel5.setText("Grade");

        snt1.setFont(new java.awt.Font("Calibri", 1, 12)); // NOI18N
        snt1.setText("snt1");

        snt2.setFont(new java.awt.Font("Calibri", 1, 12)); // NOI18N
        snt2.setText("snt2");

        snt3.setFont(new java.awt.Font("Calibri", 1, 12)); // NOI18N
        snt3.setText("snt3");

        snt4.setFont(new java.awt.Font("Calibri", 1, 12)); // NOI18N
        snt4.setText("snt4");

        snt5.setFont(new java.awt.Font("Calibri", 1, 12)); // NOI18N
        snt5.setText("snt5");

        snp1.setFont(new java.awt.Font("Calibri", 1, 12)); // NOI18N
        snp1.setText("snp1");

        snp2.setFont(new java.awt.Font("Calibri", 1, 12)); // NOI18N
        snp2.setText("snp2");

        snp3.setFont(new java.awt.Font("Calibri", 1, 12)); // NOI18N
        snp3.setText("snp3");

        snp4.setFont(new java.awt.Font("Calibri", 1, 12)); // NOI18N
        snp4.setText("snp4");

        snp5.setFont(new java.awt.Font("Calibri", 1, 12)); // NOI18N
        snp5.setText("snp5");

        snp6.setFont(new java.awt.Font("Calibri", 1, 12)); // NOI18N
        snp6.setText("snp6");

        jLabel17.setFont(new java.awt.Font("Calibri", 1, 12)); // NOI18N
        jLabel17.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel17.setText("4");

        jLabel18.setFont(new java.awt.Font("Calibri", 1, 12)); // NOI18N
        jLabel18.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel18.setText("4");

        jLabel19.setFont(new java.awt.Font("Calibri", 1, 12)); // NOI18N
        jLabel19.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel19.setText("4");

        jLabel20.setFont(new java.awt.Font("Calibri", 1, 12)); // NOI18N
        jLabel20.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel20.setText("4");

        jLabel21.setFont(new java.awt.Font("Calibri", 1, 12)); // NOI18N
        jLabel21.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel21.setText("4");

        jLabel22.setFont(new java.awt.Font("Calibri", 1, 12)); // NOI18N
        jLabel22.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel22.setText("2");

        jLabel23.setFont(new java.awt.Font("Calibri", 1, 12)); // NOI18N
        jLabel23.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel23.setText("2");

        jLabel24.setFont(new java.awt.Font("Calibri", 1, 12)); // NOI18N
        jLabel24.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel24.setText("2");

        jLabel25.setFont(new java.awt.Font("Calibri", 1, 12)); // NOI18N
        jLabel25.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel25.setText("2");

        jLabel26.setFont(new java.awt.Font("Calibri", 1, 12)); // NOI18N
        jLabel26.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel26.setText("2");

        tc.setFont(new java.awt.Font("Calibri", 1, 12)); // NOI18N
        tc.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        tc.setText("2");

        t1.setFont(new java.awt.Font("Calibri", 1, 12)); // NOI18N
        t1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        t1.setText("t1");

        t2.setFont(new java.awt.Font("Calibri", 1, 12)); // NOI18N
        t2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        t2.setText("t2");

        t3.setFont(new java.awt.Font("Calibri", 1, 12)); // NOI18N
        t3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        t3.setText("t3");

        t4.setFont(new java.awt.Font("Calibri", 1, 12)); // NOI18N
        t4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        t4.setText("t4");

        t5.setFont(new java.awt.Font("Calibri", 1, 12)); // NOI18N
        t5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        t5.setText("t5");

        p1.setFont(new java.awt.Font("Calibri", 1, 12)); // NOI18N
        p1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        p1.setText("p1");

        p2.setFont(new java.awt.Font("Calibri", 1, 12)); // NOI18N
        p2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        p2.setText("p2");

        p3.setFont(new java.awt.Font("Calibri", 1, 12)); // NOI18N
        p3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        p3.setText("p3");

        p4.setFont(new java.awt.Font("Calibri", 1, 12)); // NOI18N
        p4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        p4.setText("p4");

        p5.setFont(new java.awt.Font("Calibri", 1, 12)); // NOI18N
        p5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        p5.setText("p5");

        p6.setFont(new java.awt.Font("Calibri", 1, 12)); // NOI18N
        p6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        p6.setText("p6");

        gt1.setFont(new java.awt.Font("Calibri", 1, 12)); // NOI18N
        gt1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        gt1.setText("gt1");

        gt2.setFont(new java.awt.Font("Calibri", 1, 12)); // NOI18N
        gt2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        gt2.setText("gt2");

        gt3.setFont(new java.awt.Font("Calibri", 1, 12)); // NOI18N
        gt3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        gt3.setText("gt3");

        gt4.setFont(new java.awt.Font("Calibri", 1, 12)); // NOI18N
        gt4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        gt4.setText("gt4");

        gt5.setFont(new java.awt.Font("Calibri", 1, 12)); // NOI18N
        gt5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        gt5.setText("gt5");

        gp1.setFont(new java.awt.Font("Calibri", 1, 12)); // NOI18N
        gp1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        gp1.setText("gp1");

        gp2.setFont(new java.awt.Font("Calibri", 1, 12)); // NOI18N
        gp2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        gp2.setText("gp2");

        gp3.setFont(new java.awt.Font("Calibri", 1, 12)); // NOI18N
        gp3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        gp3.setText("gp3");

        gp4.setFont(new java.awt.Font("Calibri", 1, 12)); // NOI18N
        gp4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        gp4.setText("gp4");

        gp5.setFont(new java.awt.Font("Calibri", 1, 12)); // NOI18N
        gp5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        gp5.setText("gp5");

        gp6.setFont(new java.awt.Font("Calibri", 1, 12)); // NOI18N
        gp6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        gp6.setText("gp6");

        sct1.setFont(new java.awt.Font("Calibri", 1, 12)); // NOI18N
        sct1.setText("sct1");

        sct2.setFont(new java.awt.Font("Calibri", 1, 12)); // NOI18N
        sct2.setText("sct2");

        sct3.setFont(new java.awt.Font("Calibri", 1, 12)); // NOI18N
        sct3.setText("sct3");

        sct4.setFont(new java.awt.Font("Calibri", 1, 12)); // NOI18N
        sct4.setText("sct4");

        sct5.setFont(new java.awt.Font("Calibri", 1, 12)); // NOI18N
        sct5.setText("sct5");

        scp1.setFont(new java.awt.Font("Calibri", 1, 12)); // NOI18N
        scp1.setText("scp1");

        scp2.setFont(new java.awt.Font("Calibri", 1, 12)); // NOI18N
        scp2.setText("scp2");

        scp3.setFont(new java.awt.Font("Calibri", 1, 12)); // NOI18N
        scp3.setText("scp3");

        scp4.setFont(new java.awt.Font("Calibri", 1, 12)); // NOI18N
        scp4.setText("scp4");

        scp5.setFont(new java.awt.Font("Calibri", 1, 12)); // NOI18N
        scp5.setText("scp5");

        scp6.setFont(new java.awt.Font("Calibri", 1, 12)); // NOI18N
        scp6.setText("scp6");

        jLabel61.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        jLabel61.setText("SGPA");

        sgpa.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        sgpa.setText("sgpa");

        jLabel63.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        jLabel63.setText("CGPA");

        cgpa.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        cgpa.setText("cgpa");

        jLabel62.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resultanalysis/rgpvlogof.jpg"))); // NOI18N

        jLabel64.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel64.setText("Rajiv Gandhi Proudyogiki Vishwavidyalaya , Bhopal");

        jLabel66.setFont(new java.awt.Font("Cambria", 1, 12)); // NOI18N
        jLabel66.setText("Enrollment:");

        jLabel67.setFont(new java.awt.Font("Cambria", 1, 12)); // NOI18N
        jLabel67.setText("Name:");

        jLabel68.setFont(new java.awt.Font("Cambria", 1, 12)); // NOI18N
        jLabel68.setText("College:");

        jLabel69.setFont(new java.awt.Font("Cambria", 1, 12)); // NOI18N
        jLabel69.setText("Branch:");

        jLabel70.setFont(new java.awt.Font("Cambria", 1, 12)); // NOI18N
        jLabel70.setText("Semester:");

        jLabel71.setFont(new java.awt.Font("Cambria", 1, 12)); // NOI18N
        jLabel71.setText("Status:");

        branch.setFont(new java.awt.Font("Calibri", 1, 12)); // NOI18N
        branch.setText("branch");

        sem.setFont(new java.awt.Font("Calibri", 1, 12)); // NOI18N
        sem.setText("sem");

        jLabel74.setFont(new java.awt.Font("Calibri", 1, 12)); // NOI18N
        jLabel74.setText("Regular");

        enrollment.setFont(new java.awt.Font("Calibri", 1, 12)); // NOI18N
        enrollment.setText("enrollment");

        name.setFont(new java.awt.Font("Calibri", 1, 12)); // NOI18N
        name.setText("name");

        college.setFont(new java.awt.Font("Calibri", 1, 12)); // NOI18N
        college.setText("college");

        jLabel78.setFont(new java.awt.Font("Tahoma", 3, 12)); // NOI18N
        jLabel78.setText("Statement of Grading");

        jButton1.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jButton1.setText("OK");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        jLabel6.setText("Result");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(29, 29, 29)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(jLabel62)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel64))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel67)
                                    .addComponent(jLabel68)
                                    .addComponent(sct1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(sct2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(sct3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(sct4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(sct5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(scp1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(scp2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(scp3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(scp4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(scp5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(scp6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(71, 71, 71)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(jLabel2)
                                            .addComponent(snt1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(snt2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(snt3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(snt4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(snt5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(snp1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(snp2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(snp3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(snp4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(snp5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(snp6, javax.swing.GroupLayout.DEFAULT_SIZE, 286, Short.MAX_VALUE)))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(13, 13, 13)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(college, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addGroup(layout.createSequentialGroup()
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                                    .addComponent(enrollment, javax.swing.GroupLayout.DEFAULT_SIZE, 242, Short.MAX_VALUE)
                                                    .addComponent(name, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                                .addGap(0, 212, Short.MAX_VALUE))))))
                            .addComponent(jLabel66))
                        .addGap(24, 24, 24))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel6)
                        .addGap(54, 54, 54)
                        .addComponent(jLabel61)))
                .addGap(2, 2, 2)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel3)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel70)
                        .addComponent(jLabel69)
                        .addComponent(jLabel71))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel17)
                            .addComponent(jLabel18)
                            .addComponent(jLabel19)
                            .addComponent(jLabel20)
                            .addComponent(jLabel21)
                            .addComponent(jLabel22)
                            .addComponent(jLabel23)
                            .addComponent(jLabel24)
                            .addComponent(jLabel25)
                            .addComponent(jLabel26)
                            .addComponent(tc))
                        .addGap(38, 38, 38))
                    .addComponent(sgpa))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(49, 49, 49)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(sem)
                            .addComponent(branch)
                            .addComponent(jLabel74))
                        .addContainerGap())
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(gp5)
                            .addComponent(gp6)
                            .addComponent(gp3)
                            .addComponent(gp4)
                            .addComponent(gp1)
                            .addComponent(gp2)
                            .addComponent(gt4)
                            .addComponent(gt5)
                            .addComponent(gt3)
                            .addComponent(gt2)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addGap(28, 28, 28)
                                .addComponent(jLabel5))
                            .addComponent(gt1))
                        .addContainerGap(29, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 27, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(t3)
                                    .addComponent(t2)
                                    .addComponent(t5)
                                    .addComponent(t4)
                                    .addComponent(p2)
                                    .addComponent(p1)
                                    .addComponent(p4)
                                    .addComponent(p3)
                                    .addComponent(p6)
                                    .addComponent(p5)
                                    .addComponent(t1))
                                .addGap(110, 110, 110))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jButton1)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel63)
                                        .addGap(28, 28, 28)
                                        .addComponent(cgpa)))
                                .addGap(54, 54, 54))))))
            .addGroup(layout.createSequentialGroup()
                .addGap(327, 327, 327)
                .addComponent(jLabel78, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel64))
                    .addComponent(jLabel62, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel78)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel66)
                            .addComponent(jLabel69)
                            .addComponent(branch)
                            .addComponent(enrollment))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel67)
                            .addComponent(jLabel70)
                            .addComponent(sem)
                            .addComponent(name))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel68)
                            .addComponent(jLabel71)
                            .addComponent(jLabel74)
                            .addComponent(college))
                        .addGap(50, 50, 50)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(jLabel2)
                            .addComponent(jLabel3)
                            .addComponent(jLabel4)
                            .addComponent(jLabel5))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(snt1)
                            .addComponent(t1)
                            .addComponent(gt1)
                            .addComponent(sct1))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(snt2)
                            .addComponent(t2)
                            .addComponent(gt2)
                            .addComponent(sct2))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(snt3)
                            .addComponent(t3)
                            .addComponent(gt3)
                            .addComponent(sct3))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(snt4)
                            .addComponent(t4)
                            .addComponent(gt4)
                            .addComponent(sct4))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(snt5)
                            .addComponent(t5)
                            .addComponent(gt5)
                            .addComponent(sct5))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(snp1)
                            .addComponent(p1)
                            .addComponent(gp1)
                            .addComponent(scp1))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(snp2)
                            .addComponent(p2)
                            .addComponent(gp2)
                            .addComponent(scp2))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(snp3)
                            .addComponent(p3)
                            .addComponent(gp3)
                            .addComponent(scp3))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(snp4)
                            .addComponent(p4)
                            .addComponent(gp4)
                            .addComponent(scp4))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(snp5)
                            .addComponent(p5)
                            .addComponent(gp5)
                            .addComponent(scp5))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(snp6)
                            .addComponent(p6)
                            .addComponent(gp6)
                            .addComponent(scp6)))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel17)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel18)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel19)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel20)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel21)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel22)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel23)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel24)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel25)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel26)
                        .addGap(18, 18, 18)
                        .addComponent(tc)))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel61)
                    .addComponent(sgpa)
                    .addComponent(jLabel63)
                    .addComponent(cgpa)
                    .addComponent(jLabel6))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton1))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        this.dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    
   // public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
       /* try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(DetailResult.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(DetailResult.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(DetailResult.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(DetailResult.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>*/

        /* Create and display the dialog */
       // java.awt.EventQueue.invokeLater(new Runnable() {
           /* public void run() {
                DetailResult dialog = new DetailResult(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }*/

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel branch;
    private javax.swing.JLabel cgpa;
    private javax.swing.JLabel college;
    private javax.swing.JLabel enrollment;
    private javax.swing.JLabel gp1;
    private javax.swing.JLabel gp2;
    private javax.swing.JLabel gp3;
    private javax.swing.JLabel gp4;
    private javax.swing.JLabel gp5;
    private javax.swing.JLabel gp6;
    private javax.swing.JLabel gt1;
    private javax.swing.JLabel gt2;
    private javax.swing.JLabel gt3;
    private javax.swing.JLabel gt4;
    private javax.swing.JLabel gt5;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel61;
    private javax.swing.JLabel jLabel62;
    private javax.swing.JLabel jLabel63;
    private javax.swing.JLabel jLabel64;
    private javax.swing.JLabel jLabel66;
    private javax.swing.JLabel jLabel67;
    private javax.swing.JLabel jLabel68;
    private javax.swing.JLabel jLabel69;
    private javax.swing.JLabel jLabel70;
    private javax.swing.JLabel jLabel71;
    private javax.swing.JLabel jLabel74;
    private javax.swing.JLabel jLabel78;
    private javax.swing.JLabel name;
    private javax.swing.JLabel p1;
    private javax.swing.JLabel p2;
    private javax.swing.JLabel p3;
    private javax.swing.JLabel p4;
    private javax.swing.JLabel p5;
    private javax.swing.JLabel p6;
    private javax.swing.JLabel scp1;
    private javax.swing.JLabel scp2;
    private javax.swing.JLabel scp3;
    private javax.swing.JLabel scp4;
    private javax.swing.JLabel scp5;
    private javax.swing.JLabel scp6;
    private javax.swing.JLabel sct1;
    private javax.swing.JLabel sct2;
    private javax.swing.JLabel sct3;
    private javax.swing.JLabel sct4;
    private javax.swing.JLabel sct5;
    private javax.swing.JLabel sem;
    private javax.swing.JLabel sgpa;
    private javax.swing.JLabel snp1;
    private javax.swing.JLabel snp2;
    private javax.swing.JLabel snp3;
    private javax.swing.JLabel snp4;
    private javax.swing.JLabel snp5;
    private javax.swing.JLabel snp6;
    private javax.swing.JLabel snt1;
    private javax.swing.JLabel snt2;
    private javax.swing.JLabel snt3;
    private javax.swing.JLabel snt4;
    private javax.swing.JLabel snt5;
    private javax.swing.JLabel t1;
    private javax.swing.JLabel t2;
    private javax.swing.JLabel t3;
    private javax.swing.JLabel t4;
    private javax.swing.JLabel t5;
    private javax.swing.JLabel tc;
    // End of variables declaration//GEN-END:variables
}
