/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package resultanalysis;
import java.sql.*;
/**
 *
 * @author RAJA RAWAL
 */
public class Databaseconnection {
Connection con;
Statement stmt;
ResultSet rs;
 public Databaseconnection(){
    try{
        Class.forName("com.mysql.jdbc.Driver");
        con= DriverManager.getConnection
        ("jdbc:mysql://127.0.0.1:3306/result_analysis","root","rootwdp");
        stmt = con.createStatement();
        
    }catch(ClassNotFoundException | SQLException e){
        System.out.println(e);
    }
}
 
}
